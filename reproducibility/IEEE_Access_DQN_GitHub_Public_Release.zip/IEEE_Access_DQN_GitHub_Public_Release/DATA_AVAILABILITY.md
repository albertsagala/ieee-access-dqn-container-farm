# Suggested Data Availability Statement

The de-identified experimental data, sanitized source code, and analysis scripts supporting this study are publicly available in the accompanying GitHub repository. The repository contains DQN deployment logs, distributed-sensor records, actuator and electrical-power measurements, code for DQN training and Jetson Nano deployment, and scripts used to reproduce the reported spatial-validation analyses. Deployment credentials and private network configuration are excluded from the public release.

After a GitHub URL and, if desired, a DOI-bearing archival release are created, replace the placeholders below:

- GitHub: `GITHUB_URL`
- DOI: `DOI_URL` (optional until minted)

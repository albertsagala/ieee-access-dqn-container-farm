# DQN Training Indoor Farming

Source code sederhana untuk training ulang algoritma DQN indoor farming.

## Isi Utama

- `config.py` — konfigurasi pusat training.
- `action_mapping.py` — mapping 8 action kombinasi `(AC, Humidifier, CO2)`.
- `state_normalizer.py` — normalisasi state 11 parameter.
- `reward_function.py` — reward multi-objektif.
- `constraints.py` — action masking dan minimum ON/OFF.
- `indoor_farming_env.py` — simplified environment dynamics.
- `dqn_model.py` — model DQN `11 -> 64 -> 64 -> 8`.
- `dqn_agent.py` — agent vanilla DQN.
- `train.py` — training utama.
- `evaluate.py` — evaluasi model.
- `export_model.py` — export model ke `.npz`.

## Install

```bash
pip install -r requirements.txt
```

## Uji Komponen

```bash
python tests/test_reward.py
python tests/test_action_masking.py
python tests/test_environment.py
```

## Training Cepat Untuk Coba

```bash
python train.py --episodes 10
```

## Training Penuh

```bash
python train.py
```

Default training penuh memakai 3000 episode. Output tersimpan di folder `outputs/`.

## Evaluasi

```bash
python evaluate.py --model outputs/models/best_model.pth
```

## Export Model

```bash
python export_model.py --model outputs/models/best_model.pth --output outputs/models/dqn_weights.npz
```

## Catatan Penting

- Algoritma masih Vanilla DQN, bukan Double DQN dan bukan Dueling DQN.
- Action masking diterapkan saat eksplorasi dan eksploitasi.
- Minimum ON/OFF:
  - AC: ON 1 step, OFF 2 step.
  - Humidifier: ON 1 step, OFF 2 step.
  - CO2: ON 1 step, OFF 1 step.
- 1 step = 15 menit, 1 episode = 96 step = 24 jam.

# Ukuran state dan action
STATE_SIZE = 11
ACTION_SIZE = 8

STATE_NAMES = [
    "T_in", "RH_in", "Lux_in", "CO2_in",
    "T_out", "RH_out", "Lux_out",
    "AC", "H", "C", "L"
]

# Waktu simulasi
STEP_MINUTES = 15
STEPS_PER_EPISODE = 96  # 24 jam x 4 step per jam
EPISODES = 3000

# Hyperparameter DQN
GAMMA = 0.95
LEARNING_RATE = 1e-4
BATCH_SIZE = 64
REPLAY_BUFFER_SIZE = 50_000
MIN_REPLAY_SIZE = 2_000
TARGET_UPDATE_FREQ = 500  # update target network setiap n train step

EPSILON_START = 1.0
EPSILON_FINAL = 0.02
EPSILON_DECAY = 0.9975  # decay per episode

GRADIENT_CLIP = 10.0
EVALUATION_INTERVAL = 50
EVAL_EPISODES = 10

# Daya aktuator untuk reward training
POWER_AC = 700.0
POWER_HUMIDIFIER = 15.0
POWER_CO2 = 1.0
POWER_LAMP = 153.0
POWER_MAX = 869.0

# Bobot reward
BONUS_VALUE = 20.0
LAMBDA_T = 60.0
LAMBDA_CO2 = 30.0
LAMBDA_RH = 20.0
LAMBDA_ENERGY = 5.0

SWITCH_PENALTY_AC = 3.0
SWITCH_PENALTY_H = 1.0
SWITCH_PENALTY_CO2 = 1.0
UNSAFE_PENALTY = 100.0

# Zona ideal dan unsafe
TEMP_IDEAL_MIN = 20.0
TEMP_IDEAL_MAX = 24.0
RH_IDEAL_MIN = 60.0
RH_IDEAL_MAX = 70.0
CO2_IDEAL_MIN = 800.0
CO2_IDEAL_MAX = 1000.0

TEMP_UNSAFE_LOW = 17.0
TEMP_UNSAFE_HIGH = 28.0
RH_UNSAFE_LOW = 40.0
RH_UNSAFE_HIGH = 95.0
CO2_UNSAFE_LOW_LIGHT = 550.0
CO2_UNSAFE_HIGH = 1200.0

# Normalisasi state
NORM = {
    "T_in": (16.0, 35.0),
    "RH_in": (35.0, 100.0),
    "Lux_in": (0.0, 3000.0),
    "CO2_in": (400.0, 1300.0),
    "T_out": (15.0, 45.0),
    "RH_out": (30.0, 100.0),
    "Lux_out": (0.0, 55000.0),
}

# Environment dynamics sederhana
# Suhu
ALPHA_T = 0.05
BETA_L = 0.20
BETA_INT = 0.03
GAMMA_AC = 2.00
SIGMA_T = 0.10

# RH
ALPHA_H = 0.03
BETA_H = 2.00
GAMMA_HAC = 2.50
ETA_T = 0.50
SIGMA_H = 0.50

# CO2
ALPHA_C = 0.04
BETA_C = 60.0
RHO_PHOTO = 25.0
RHO_DARK = 5.0
C_OUT = 420.0
SIGMA_C = 8.0

# Batas clip environment
T_IN_MIN = 16.0
T_IN_MAX = 35.0
RH_IN_MIN = 35.0
RH_IN_MAX = 100.0
CO2_IN_MIN = 400.0
CO2_IN_MAX = 1300.0

# Lampu dan lux
LAMP_ON_HOUR = 6.0
LAMP_OFF_HOUR = 22.0

# Dinamika lux tetap sederhana,Normalisasi lux tetap /3000 dan /55000.
LUX_IN_ON_MEAN = 2400.0
LUX_IN_ON_STD = 80.0
LUX_IN_MAX_CLIP = 3000.0
LUX_OUT_MAX_SYNTHETIC = 60000.0

# Minimum ON/OFF constraint
MIN_ON_STEPS = {
    "ac": 1,
    "h": 1,
    "co2": 1,
}

MIN_OFF_STEPS = {
    "ac": 2,
    "h": 2,
    "co2": 1,
}

# Logging dan output
OUTPUT_DIR = "outputs"
MODEL_DIR = "outputs/models"
LOG_DIR = "outputs/logs"
CONFIG_DIR = "outputs/configs"
PLOT_DIR = "outputs/plots"

RANDOM_SEED = 42

"""
Perhitungan metrik episode dan evaluasi.
Input utama berupa list step_log dari environment/training.
"""
import config


def compute_episode_metrics(step_logs: list) -> dict:
    if not step_logs:
        return {}

    n = len(step_logs)
    total_reward = sum(row["reward"] for row in step_logs)

    temp_ideal = sum(1 for row in step_logs if config.TEMP_IDEAL_MIN <= row["T_in"] <= config.TEMP_IDEAL_MAX)
    rh_ideal = sum(1 for row in step_logs if config.RH_IDEAL_MIN <= row["RH_in"] <= config.RH_IDEAL_MAX)

    lamp_on_steps = [row for row in step_logs if int(row["lamp"]) == 1]
    if lamp_on_steps:
        co2_ideal = sum(1 for row in lamp_on_steps if config.CO2_IDEAL_MIN <= row["CO2_in"] <= config.CO2_IDEAL_MAX)
        co2_ideal_pct = 100.0 * co2_ideal / len(lamp_on_steps)
    else:
        co2_ideal_pct = 0.0

    ac_on_steps = sum(int(row["AC"]) for row in step_logs)
    h_on_steps = sum(int(row["H"]) for row in step_logs)
    co2_on_steps = sum(int(row["C"]) for row in step_logs)

    ac_switch = 0
    h_switch = 0
    co2_switch = 0
    for i in range(1, n):
        ac_switch += int(step_logs[i]["AC"] != step_logs[i - 1]["AC"])
        h_switch += int(step_logs[i]["H"] != step_logs[i - 1]["H"])
        co2_switch += int(step_logs[i]["C"] != step_logs[i - 1]["C"])

    total_energy_kwh = sum(row.get("power_nominal", 0.0) * (config.STEP_MINUTES / 60.0) / 1000.0 for row in step_logs)
    unsafe_count = sum(1 for row in step_logs if row.get("unsafe_penalty", 0.0) > 0)

    return {
        "total_reward": total_reward,
        "avg_reward": total_reward / n,
        "temp_ideal_pct": 100.0 * temp_ideal / n,
        "rh_ideal_pct": 100.0 * rh_ideal / n,
        "co2_ideal_pct": co2_ideal_pct,
        "total_energy_kwh": total_energy_kwh,
        "ac_on_steps": ac_on_steps,
        "hum_on_steps": h_on_steps,
        "co2_on_steps": co2_on_steps,
        "ac_switch_count": ac_switch,
        "hum_switch_count": h_switch,
        "co2_switch_count": co2_switch,
        "switch_count_total": ac_switch + h_switch + co2_switch,
        "unsafe_count": unsafe_count,
    }


def average_metrics(metrics_list: list) -> dict:
    if not metrics_list:
        return {}
    result = {}
    keys = set().union(*(m.keys() for m in metrics_list))
    for key in keys:
        values = [m[key] for m in metrics_list if key in m]
        numeric_values = [
            v for v in values
            if isinstance(v, (int, float)) and not isinstance(v, bool)
        ]
        if numeric_values:
            result[key] = sum(numeric_values) / len(numeric_values)
    return result


def model_selection_score(metrics: dict) -> float:
    temp = metrics.get("temp_ideal_pct", 0.0)
    rh = metrics.get("rh_ideal_pct", 0.0)
    co2 = metrics.get("co2_ideal_pct", 0.0)
    energy = metrics.get("total_energy_kwh", 0.0)
    switch_count = metrics.get("switch_count_total", 0.0)
    unsafe = metrics.get("unsafe_count", 0.0)

    # Normalisasi kasar agar skala tidak terlalu besar.
    energy_norm = energy * 10.0
    switch_norm = switch_count

    return (
        0.40 * temp
        + 0.20 * rh
        + 0.15 * co2
        - 0.10 * energy_norm
        - 0.10 * switch_norm
        - 10.0 * unsafe
    )

from typing import Dict, List, Optional
import numpy as np

import config
from action_mapping import ACTION_MAP, decode_action, encode_action, all_actions


def required_status_from_safety(state) -> Dict[str, Optional[int]]:
    """Menghasilkan status wajib berdasarkan safety/action masking.

    Nilai None berarti tidak ada paksaan untuk aktuator tersebut.
    """
    T, RH, Lux_in, CO2, T_out, RH_out, Lux_out, ac, h, c, lamp = state
    req = {"ac": None, "h": None, "co2": None}

    # AC
    if T <= 20.0:
        req["ac"] = 0
    elif T > 24.5:
        req["ac"] = 1

    # Humidifier
    if RH <= 50.0:
        req["h"] = 1
    elif RH >= 70.0:
        req["h"] = 0

    # CO2
    if int(lamp) == 0:
        req["co2"] = 0
    elif CO2 >= 1000.0:
        req["co2"] = 0
    elif int(lamp) == 1 and CO2 <= 500.0:
        req["co2"] = 1

    return req


def _satisfy_safety(status: Dict[str, int], required: Dict[str, Optional[int]]) -> bool:
    for key, value in required.items():
        if value is not None and int(status[key]) != int(value):
            return False
    return True


def _satisfy_min_on_off(
    status: Dict[str, int],
    current_status: Dict[str, int],
    durations: Dict[str, int],
    required: Dict[str, Optional[int]],
) -> bool:
    """Cek minimum ON/OFF.

    Jika safety memaksa aktuator ke status tertentu, aturan minimum boleh dilewati.
    durations menyimpan berapa step aktuator berada di status sekarang.
    """
    for key in ["ac", "h", "co2"]:
        desired = int(status[key])
        current = int(current_status[key])
        duration = int(durations[key])

        # Safety override untuk aktuator ini.
        if required.get(key) is not None and desired == int(required[key]):
            continue

        # Ingin OFF setelah ON: harus memenuhi min ON.
        if current == 1 and desired == 0:
            if duration < config.MIN_ON_STEPS[key]:
                return False

        # Ingin ON setelah OFF: harus memenuhi min OFF.
        if current == 0 and desired == 1:
            if duration < config.MIN_OFF_STEPS[key]:
                return False

    return True


def get_valid_actions(state, current_status: Dict[str, int], durations: Dict[str, int]) -> List[int]:
    """Daftar action yang valid berdasarkan state, action masking, dan min ON/OFF."""
    required = required_status_from_safety(state)
    valid = []
    for action_id in all_actions():
        status = decode_action(action_id)
        if not _satisfy_safety(status, required):
            continue
        if not _satisfy_min_on_off(status, current_status, durations, required):
            continue
        valid.append(action_id)

    # Fallback agar tidak pernah kosong.
    if not valid:
        valid.append(fallback_action(state, current_status))

    return valid


def fallback_action(state, current_status: Dict[str, int]) -> int:
    """Action aman jika semua action terhapus oleh constraint."""
    required = required_status_from_safety(state)
    ac = current_status["ac"] if required["ac"] is None else required["ac"]
    h = current_status["h"] if required["h"] is None else required["h"]
    co2 = current_status["co2"] if required["co2"] is None else required["co2"]
    return encode_action(int(ac), int(h), int(co2))


def apply_action_mask(q_values, valid_actions: List[int]):
    """Set Q-value action invalid menjadi sangat kecil."""
    masked = np.array(q_values, dtype=np.float32).copy()
    invalid = set(range(config.ACTION_SIZE)) - set(valid_actions)
    for idx in invalid:
        masked[idx] = -1e9
    return masked


def apply_final_action(
    requested_action: int,
    state,
    current_status: Dict[str, int],
    durations: Dict[str, int],
):
    """Pastikan action yang diterapkan valid.

    Jika requested_action invalid, gunakan fallback action pertama dari valid_actions.
    """
    valid_actions = get_valid_actions(state, current_status, durations)
    if requested_action in valid_actions:
        final_action = requested_action
    else:
        final_action = valid_actions[0]
    return final_action, valid_actions


def update_durations(current_status: Dict[str, int], new_status: Dict[str, int], durations: Dict[str, int]) -> Dict[str, int]:
    """Update counter durasi status aktuator."""
    updated = {}
    for key in ["ac", "h", "co2"]:
        if int(new_status[key]) == int(current_status[key]):
            updated[key] = int(durations[key]) + 1
        else:
            updated[key] = 1
    return updated

"""
Arsitektur: 11 -> 64 -> 64 -> 8
"""
import torch
import torch.nn as nn


class DQNModel(nn.Module):
    def __init__(self, state_size: int = 11, action_size: int = 8):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_size, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Linear(64, action_size),
        )

    def forward(self, x):
        return self.net(x)

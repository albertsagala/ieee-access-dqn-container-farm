"""
Export model PyTorch ke file NPZ sederhana untuk deployment ringan.
"""
import argparse
import json
import numpy as np
import torch

import config
from dqn_agent import DQNAgent
from action_mapping import ACTION_MAP
from state_normalizer import normalization_config
from logger import ensure_dirs


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, default=f"{config.MODEL_DIR}/best_model.pth")
    parser.add_argument("--output", type=str, default=f"{config.MODEL_DIR}/dqn_weights.npz")
    args = parser.parse_args()

    ensure_dirs()
    agent = DQNAgent(device="cpu")
    agent.load_model(args.model)
    model = agent.policy_net.cpu().eval()

    arrays = {}
    for name, tensor in model.state_dict().items():
        arrays[name.replace(".", "_")] = tensor.detach().cpu().numpy()

    np.savez(args.output, **arrays)

    with open(f"{config.CONFIG_DIR}/export_action_mapping.json", "w", encoding="utf-8") as f:
        json.dump(ACTION_MAP, f, indent=2)
    with open(f"{config.CONFIG_DIR}/export_normalization_config.json", "w", encoding="utf-8") as f:
        json.dump(normalization_config(), f, indent=2)

    print(f"Model berhasil diekspor ke {args.output}")


if __name__ == "__main__":
    main()

import config


def compute_errors(T: float, RH: float, CO2: float, lamp: int) -> dict:
    # Error suhu: nol jika 20-24 C
    if config.TEMP_IDEAL_MIN <= T <= config.TEMP_IDEAL_MAX:
        e_T = 0.0
    elif T > config.TEMP_IDEAL_MAX:
        e_T = T - config.TEMP_IDEAL_MAX
    else:
        e_T = config.TEMP_IDEAL_MIN - T

    # Error RH: nol jika 60-70%
    if config.RH_IDEAL_MIN <= RH <= config.RH_IDEAL_MAX:
        e_RH = 0.0
    elif RH > config.RH_IDEAL_MAX:
        e_RH = RH - config.RH_IDEAL_MAX
    else:
        e_RH = config.RH_IDEAL_MIN - RH

    # Error CO2 hanya aktif saat lampu ON
    if lamp == 0:
        e_CO2 = 0.0
    elif config.CO2_IDEAL_MIN <= CO2 <= config.CO2_IDEAL_MAX:
        e_CO2 = 0.0
    elif CO2 < config.CO2_IDEAL_MIN:
        e_CO2 = config.CO2_IDEAL_MIN - CO2
    else:
        e_CO2 = CO2 - config.CO2_IDEAL_MAX

    return {"e_T": e_T, "e_RH": e_RH, "e_CO2": e_CO2}


def compute_bonus(T: float, RH: float, CO2: float, lamp: int) -> dict:
    B_T = config.BONUS_VALUE if config.TEMP_IDEAL_MIN <= T <= config.TEMP_IDEAL_MAX else 0.0
    B_RH = config.BONUS_VALUE if config.RH_IDEAL_MIN <= RH <= config.RH_IDEAL_MAX else 0.0
    B_CO2 = config.BONUS_VALUE if (lamp == 1 and config.CO2_IDEAL_MIN <= CO2 <= config.CO2_IDEAL_MAX) else 0.0
    return {"B_T": B_T, "B_RH": B_RH, "B_CO2": B_CO2}


def compute_unsafe_penalty(T: float, RH: float, CO2: float, lamp: int) -> float:
    penalties = [0.0]
    if T > config.TEMP_UNSAFE_HIGH or T < config.TEMP_UNSAFE_LOW:
        penalties.append(config.UNSAFE_PENALTY)
    if RH > config.RH_UNSAFE_HIGH or RH < config.RH_UNSAFE_LOW:
        penalties.append(config.UNSAFE_PENALTY)
    if CO2 > config.CO2_UNSAFE_HIGH:
        penalties.append(config.UNSAFE_PENALTY)
    if lamp == 1 and CO2 < config.CO2_UNSAFE_LOW_LIGHT:
        penalties.append(config.UNSAFE_PENALTY)
    return max(penalties)


def compute_reward(next_state, action_status: dict, prev_status: dict):
    """
    Reward dihitung dari state berikutnya dan action final yang diterapkan.

    next_state: state mentah setelah transisi.
    action_status: {"ac":0/1, "h":0/1, "co2":0/1}
    prev_status: {"ac":0/1, "h":0/1, "co2":0/1}
    """
    T, RH, Lux_in, CO2, T_out, RH_out, Lux_out, ac_state, h_state, co2_state, lamp = next_state
    ac = int(action_status["ac"])
    h = int(action_status["h"])
    co2 = int(action_status["co2"])
    lamp = int(lamp)

    errors = compute_errors(T, RH, CO2, lamp)
    bonus = compute_bonus(T, RH, CO2, lamp)

    temp_penalty = config.LAMBDA_T * (errors["e_T"] / 4.0) ** 2
    co2_penalty = config.LAMBDA_CO2 * (errors["e_CO2"] / 400.0) ** 2
    rh_penalty = config.LAMBDA_RH * (errors["e_RH"] / 20.0) ** 2

    power = (
        config.POWER_AC * ac
        + config.POWER_HUMIDIFIER * h
        + config.POWER_CO2 * co2
        + config.POWER_LAMP * lamp
    )
    energy_penalty = config.LAMBDA_ENERGY * (power / config.POWER_MAX)

    switch_penalty = (
        config.SWITCH_PENALTY_AC * abs(ac - int(prev_status["ac"]))
        + config.SWITCH_PENALTY_H * abs(h - int(prev_status["h"]))
        + config.SWITCH_PENALTY_CO2 * abs(co2 - int(prev_status["co2"]))
    )

    unsafe_penalty = compute_unsafe_penalty(T, RH, CO2, lamp)
    bonus_total = bonus["B_T"] + bonus["B_RH"] + bonus["B_CO2"]

    reward = (
        bonus_total
        - temp_penalty
        - co2_penalty
        - rh_penalty
        - energy_penalty
        - switch_penalty
        - unsafe_penalty
    )

    info = {
        **errors,
        **bonus,
        "bonus_total": bonus_total,
        "temp_penalty": temp_penalty,
        "co2_penalty": co2_penalty,
        "rh_penalty": rh_penalty,
        "energy_penalty": energy_penalty,
        "switch_penalty": switch_penalty,
        "unsafe_penalty": unsafe_penalty,
        "power_nominal": power,
        "reward": reward,
    }
    return float(reward), info

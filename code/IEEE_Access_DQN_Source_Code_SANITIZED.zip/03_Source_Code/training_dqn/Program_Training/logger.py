import csv
import json
import os
from pathlib import Path

import config
from action_mapping import ACTION_MAP
from state_normalizer import normalization_config


def ensure_dirs():
    for path in [config.MODEL_DIR, config.LOG_DIR, config.CONFIG_DIR, config.PLOT_DIR, f"{config.MODEL_DIR}/checkpoints"]:
        Path(path).mkdir(parents=True, exist_ok=True)


def append_csv(path: str, row: dict):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    file_exists = os.path.exists(path)
    with open(path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(row.keys()))
        if not file_exists:
            writer.writeheader()
        writer.writerow(row)


def write_csv(path: str, rows: list):
    if not rows:
        return
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def save_json(path: str, data: dict):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def save_configs():
    ensure_dirs()
    training_config = {
        "STATE_SIZE": config.STATE_SIZE,
        "ACTION_SIZE": config.ACTION_SIZE,
        "STEP_MINUTES": config.STEP_MINUTES,
        "STEPS_PER_EPISODE": config.STEPS_PER_EPISODE,
        "EPISODES": config.EPISODES,
        "GAMMA": config.GAMMA,
        "LEARNING_RATE": config.LEARNING_RATE,
        "BATCH_SIZE": config.BATCH_SIZE,
        "REPLAY_BUFFER_SIZE": config.REPLAY_BUFFER_SIZE,
        "MIN_REPLAY_SIZE": config.MIN_REPLAY_SIZE,
        "TARGET_UPDATE_FREQ": config.TARGET_UPDATE_FREQ,
        "EPSILON_START": config.EPSILON_START,
        "EPSILON_FINAL": config.EPSILON_FINAL,
        "EPSILON_DECAY": config.EPSILON_DECAY,
        "POWER_AC": config.POWER_AC,
        "POWER_HUMIDIFIER": config.POWER_HUMIDIFIER,
        "POWER_CO2": config.POWER_CO2,
        "POWER_LAMP": config.POWER_LAMP,
        "POWER_MAX": config.POWER_MAX,
        "ARCHITECTURE": "11-64-64-8",
        "ALGORITHM": "Vanilla DQN",
    }
    save_json(f"{config.CONFIG_DIR}/training_config.json", training_config)
    save_json(f"{config.CONFIG_DIR}/normalization_config.json", normalization_config())
    save_json(f"{config.CONFIG_DIR}/action_mapping.json", ACTION_MAP)


def step_log_row(episode: int, step: int, state, action_info: dict, reward_info: dict):
    T, RH, Lux_in, CO2, T_out, RH_out, Lux_out, ac, h, c, lamp = state
    row = {
        "episode": episode,
        "step": step,
        "hour": action_info.get("hour", 0.0),
        "T_in": float(T),
        "RH_in": float(RH),
        "Lux_in": float(Lux_in),
        "CO2_in": float(CO2),
        "T_out": float(T_out),
        "RH_out": float(RH_out),
        "Lux_out": float(Lux_out),
        "AC": int(ac),
        "H": int(h),
        "C": int(c),
        "lamp": int(lamp),
        "requested_action": action_info.get("requested_action"),
        "final_action": action_info.get("final_action"),
        "final_label": action_info.get("final_label"),
        "valid_actions": str(action_info.get("valid_actions", [])),
    }
    for key, value in reward_info.items():
        if isinstance(value, (int, float)) or hasattr(value, "item"):
            try:
                row[key] = float(value)
            except Exception:
                pass
    return row

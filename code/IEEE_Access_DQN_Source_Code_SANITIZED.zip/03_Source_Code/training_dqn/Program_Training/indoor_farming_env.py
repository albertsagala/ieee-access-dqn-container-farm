import math
import random
from typing import Dict, Tuple

import numpy as np

import config
from action_mapping import decode_action, encode_action, action_label
from constraints import apply_final_action, get_valid_actions, update_durations
from reward_function import compute_reward


class IndoorFarmingEnv:
    def __init__(self, seed: int = None):
        self.rng = np.random.default_rng(seed if seed is not None else config.RANDOM_SEED)
        random.seed(seed if seed is not None else config.RANDOM_SEED)
        self.state = None
        self.step_idx = 0
        self.start_hour = 0.0
        self.current_status = {"ac": 0, "h": 0, "co2": 0}
        self.durations = {
            "ac": config.MIN_OFF_STEPS["ac"],
            "h": config.MIN_OFF_STEPS["h"],
            "co2": config.MIN_OFF_STEPS["co2"],
        }

    # Fungsi waktu dan kondisi luar
    def hour(self) -> float:
        return (self.start_hour + self.step_idx * config.STEP_MINUTES / 60.0) % 24.0

    @staticmethod
    def lamp_status(hour: float) -> int:
        return int(config.LAMP_ON_HOUR <= hour < config.LAMP_OFF_HOUR)

    def outdoor_temperature(self, hour: float) -> float:
        value = 26.0 + 4.0 * math.sin(2.0 * math.pi * (hour - 8.0) / 24.0)
        value += self.rng.normal(0.0, 0.5)
        return float(np.clip(value, 15.0, 45.0))

    def outdoor_humidity(self, hour: float) -> float:
        value = 85.0 - 10.0 * math.sin(2.0 * math.pi * (hour - 8.0) / 24.0)
        value += self.rng.normal(0.0, 3.0)
        return float(np.clip(value, 30.0, 100.0))

    def outdoor_lux(self, hour: float) -> float:
        # Dinamika lux outdoor tetap sederhana, tidak memakai spike acak.
        if 6.0 <= hour <= 18.0:
            value = config.LUX_OUT_MAX_SYNTHETIC * math.sin(math.pi * (hour - 6.0) / 12.0)
            return float(max(0.0, value))
        return 0.0

    def indoor_lux(self, lamp: int) -> float:
        if lamp == 1:
            value = self.rng.normal(config.LUX_IN_ON_MEAN, config.LUX_IN_ON_STD)
            return float(np.clip(value, 0.0, config.LUX_IN_MAX_CLIP))
        return 0.0

    # Reset dan skenario awal
    def sample_initial_condition(self, scenario: str = None) -> Tuple[float, float, float]:
        if scenario is None:
            scenario = self.sample_scenario()

        if scenario == "normal":
            T = self.rng.uniform(22.0, 25.0)
            RH = self.rng.uniform(60.0, 75.0)
            CO2 = self.rng.uniform(650.0, 850.0)
        elif scenario == "hot":
            T = self.rng.uniform(25.0, 28.0)
            RH = self.rng.uniform(65.0, 90.0)
            CO2 = self.rng.uniform(550.0, 800.0)
        elif scenario == "high_rh":
            T = self.rng.uniform(22.0, 26.0)
            RH = self.rng.uniform(80.0, 95.0)
            CO2 = self.rng.uniform(550.0, 850.0)
        elif scenario == "low_co2":
            T = self.rng.uniform(21.0, 25.0)
            RH = self.rng.uniform(60.0, 85.0)
            CO2 = self.rng.uniform(450.0, 650.0)
        elif scenario == "bad_mix":
            T = self.rng.uniform(25.0, 28.0)
            RH = self.rng.uniform(80.0, 95.0)
            CO2 = self.rng.uniform(450.0, 650.0)
        else:
            raise ValueError(f"Skenario tidak dikenal: {scenario}")

        return float(T), float(RH), float(CO2)

    def sample_scenario(self) -> str:
        scenarios = ["normal", "hot", "high_rh", "low_co2", "bad_mix"]
        probs = [0.25, 0.20, 0.20, 0.20, 0.15]
        return str(self.rng.choice(scenarios, p=probs))

    def reset(self, scenario: str = None):
        self.step_idx = 0
        self.start_hour = float(self.rng.uniform(0.0, 24.0))

        T, RH, CO2 = self.sample_initial_condition(scenario)
        hour = self.hour()
        lamp = self.lamp_status(hour)
        T_out = self.outdoor_temperature(hour)
        RH_out = self.outdoor_humidity(hour)
        Lux_out = self.outdoor_lux(hour)
        Lux_in = self.indoor_lux(lamp)

        self.current_status = {"ac": 0, "h": 0, "co2": 0}
        self.durations = {
            "ac": config.MIN_OFF_STEPS["ac"],
            "h": config.MIN_OFF_STEPS["h"],
            "co2": config.MIN_OFF_STEPS["co2"],
        }

        self.state = np.array([
            T, RH, Lux_in, CO2,
            T_out, RH_out, Lux_out,
            0, 0, 0, lamp,
        ], dtype=np.float32)
        return self.state.copy()

    # Dynamics
    def simulate_dynamics(self, action_status: Dict[str, int]):
        T, RH, Lux_in, CO2, T_out, RH_out, Lux_out, prev_ac, prev_h, prev_c, lamp = self.state
        hour_next = (self.start_hour + (self.step_idx + 1) * config.STEP_MINUTES / 60.0) % 24.0
        lamp_next = self.lamp_status(hour_next)

        ac = int(action_status["ac"])
        h = int(action_status["h"])
        co2 = int(action_status["co2"])

        # Suhu indoor
        eps_T = self.rng.normal(0.0, config.SIGMA_T)
        T_next = (
            T
            + config.ALPHA_T * (T_out - T)
            + config.BETA_L * int(lamp)
            + config.BETA_INT
            - config.GAMMA_AC * ac
            + eps_T
        )
        T_next = float(np.clip(T_next, config.T_IN_MIN, config.T_IN_MAX))

        # RH indoor. Memakai perubahan suhu T(k)-T(k+1).
        eps_H = self.rng.normal(0.0, config.SIGMA_H)
        RH_next = (
            RH
            + config.ALPHA_H * (RH_out - RH)
            + config.BETA_H * h
            - config.GAMMA_HAC * ac
            + config.ETA_T * (T - T_next)
            + eps_H
        )
        RH_next = float(np.clip(RH_next, config.RH_IN_MIN, config.RH_IN_MAX))

        # CO2 indoor
        eps_C = self.rng.normal(0.0, config.SIGMA_C)
        CO2_next = (
            CO2
            + config.ALPHA_C * (config.C_OUT - CO2)
            + config.BETA_C * co2
            - config.RHO_PHOTO * int(lamp)
            + config.RHO_DARK * (1 - int(lamp))
            + eps_C
        )
        CO2_next = float(np.clip(CO2_next, config.CO2_IN_MIN, config.CO2_IN_MAX))

        # Kondisi luar step berikutnya dan lux
        T_out_next = self.outdoor_temperature(hour_next)
        RH_out_next = self.outdoor_humidity(hour_next)
        Lux_out_next = self.outdoor_lux(hour_next)
        Lux_in_next = self.indoor_lux(lamp_next)

        next_state = np.array([
            T_next, RH_next, Lux_in_next, CO2_next,
            T_out_next, RH_out_next, Lux_out_next,
            ac, h, co2, lamp_next,
        ], dtype=np.float32)
        return next_state

    # Step environment
    def get_valid_actions(self):
        return get_valid_actions(self.state, self.current_status, self.durations)

    def step(self, requested_action: int):
        prev_state = self.state.copy()
        prev_status = self.current_status.copy()

        final_action, valid_actions = apply_final_action(
            requested_action,
            self.state,
            self.current_status,
            self.durations,
        )
        action_status = decode_action(final_action)

        next_state = self.simulate_dynamics(action_status)
        reward, reward_info = compute_reward(next_state, action_status, prev_status)

        # Update status dan durasi setelah action final diterapkan.
        self.durations = update_durations(self.current_status, action_status, self.durations)
        self.current_status = action_status.copy()
        self.state = next_state
        self.step_idx += 1
        done = self.step_idx >= config.STEPS_PER_EPISODE

        info = {
            "requested_action": requested_action,
            "final_action": final_action,
            "requested_label": action_label(requested_action),
            "final_label": action_label(final_action),
            "valid_actions": valid_actions,
            "prev_status": prev_status,
            "action_status": action_status,
            "durations": self.durations.copy(),
            "hour": self.hour(),
            **reward_info,
        }
        return next_state.copy(), reward, done, info

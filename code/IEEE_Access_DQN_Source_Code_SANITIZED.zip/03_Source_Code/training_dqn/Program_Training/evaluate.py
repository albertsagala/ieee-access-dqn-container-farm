"""
Evaluasi model DQN yang sudah dilatih.
"""
import argparse

import config
from dqn_agent import DQNAgent
from indoor_farming_env import IndoorFarmingEnv
from train import run_episode, EVAL_SCENARIOS
from metrics import average_metrics, model_selection_score
from logger import ensure_dirs, write_csv, append_csv


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, default=f"{config.MODEL_DIR}/best_model.pth")
    parser.add_argument("--episodes", type=int, default=config.EVAL_EPISODES)
    args = parser.parse_args()

    ensure_dirs()
    agent = DQNAgent()
    agent.load_model(args.model)

    metrics_list = []
    all_steps = []
    scenarios = [EVAL_SCENARIOS[i % len(EVAL_SCENARIOS)] for i in range(args.episodes)]
    for i, scenario in enumerate(scenarios):
        env = IndoorFarmingEnv(seed=config.RANDOM_SEED + 20_000 + i)
        metrics, step_logs = run_episode(env, agent, epsilon=0.0, episode_idx=i, train=False, scenario=scenario)
        metrics["scenario"] = scenario
        metrics_list.append(metrics)
        all_steps.extend(step_logs)

    avg = average_metrics(metrics_list)
    avg["model_score"] = model_selection_score(avg)

    print("Hasil evaluasi:")
    for key, value in avg.items():
        print(f"  {key}: {value}")

    write_csv(f"{config.LOG_DIR}/manual_evaluation_step_log.csv", all_steps)
    append_csv(f"{config.LOG_DIR}/manual_evaluation_summary.csv", avg)


if __name__ == "__main__":
    main()

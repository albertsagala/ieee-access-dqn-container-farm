import numpy as np
import config


def clip01(x: float) -> float:
    return float(np.clip(x, 0.0, 1.0))


def minmax(value: float, min_value: float, max_value: float) -> float:
    if max_value == min_value:
        return 0.0
    return clip01((float(value) - min_value) / (max_value - min_value))


def normalize_state(state) -> np.ndarray:
    """Mengubah state mentah menjadi state normalisasi float32."""
    T_in, RH_in, Lux_in, CO2_in, T_out, RH_out, Lux_out, ac, h, co2, lamp = state

    normalized = [
        minmax(T_in, *config.NORM["T_in"]),
        minmax(RH_in, *config.NORM["RH_in"]),
        minmax(Lux_in, *config.NORM["Lux_in"]),
        minmax(CO2_in, *config.NORM["CO2_in"]),
        minmax(T_out, *config.NORM["T_out"]),
        minmax(RH_out, *config.NORM["RH_out"]),
        minmax(Lux_out, *config.NORM["Lux_out"]),
        float(ac),
        float(h),
        float(co2),
        float(lamp),
    ]
    return np.asarray(normalized, dtype=np.float32)


def normalization_config() -> dict:
    """Dipakai untuk menyimpan konfigurasi normalisasi ke JSON."""
    return {
        "state_order": config.STATE_NAMES,
        "normalization": config.NORM,
        "binary_features": ["AC", "H", "C", "L"],
    }

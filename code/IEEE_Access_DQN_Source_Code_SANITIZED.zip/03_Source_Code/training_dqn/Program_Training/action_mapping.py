"""
Mapping action DQN ke kombinasi status aktuator.
Action DQN tidak mengatur lampu. Lampu mengikuti jadwal photoperiod.
"""

ACTION_MAP = {
    0: {"ac": 0, "h": 0, "co2": 0, "label": "ALL_OFF"},
    1: {"ac": 1, "h": 0, "co2": 0, "label": "AC_ON"},
    2: {"ac": 0, "h": 1, "co2": 0, "label": "H_ON"},
    3: {"ac": 0, "h": 0, "co2": 1, "label": "CO2_ON"},
    4: {"ac": 1, "h": 1, "co2": 0, "label": "AC_H_ON"},
    5: {"ac": 1, "h": 0, "co2": 1, "label": "AC_CO2_ON"},
    6: {"ac": 0, "h": 1, "co2": 1, "label": "H_CO2_ON"},
    7: {"ac": 1, "h": 1, "co2": 1, "label": "AC_H_CO2_ON"},
}


def decode_action(action_id: int) -> dict:
    """Mengubah action id menjadi status aktuator."""
    if action_id not in ACTION_MAP:
        raise ValueError(f"Action tidak dikenal: {action_id}")
    item = ACTION_MAP[action_id]
    return {"ac": item["ac"], "h": item["h"], "co2": item["co2"]}


def encode_action(ac: int, h: int, co2: int) -> int:
    """Mengubah status aktuator menjadi action id."""
    for action_id, item in ACTION_MAP.items():
        if item["ac"] == ac and item["h"] == h and item["co2"] == co2:
            return action_id
    raise ValueError(f"Kombinasi action tidak valid: ac={ac}, h={h}, co2={co2}")


def action_label(action_id: int) -> str:
    return ACTION_MAP[action_id]["label"]


def all_actions() -> list:
    return list(ACTION_MAP.keys())

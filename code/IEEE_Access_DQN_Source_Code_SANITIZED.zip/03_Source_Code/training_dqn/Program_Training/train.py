"""
File utama training DQN.
"""
import argparse
import os
import random
import numpy as np
import torch

import config
from dqn_agent import DQNAgent
from indoor_farming_env import IndoorFarmingEnv
from replay_buffer import ReplayBuffer
from state_normalizer import normalize_state
from metrics import compute_episode_metrics, average_metrics, model_selection_score
from logger import ensure_dirs, append_csv, write_csv, save_configs, step_log_row


EVAL_SCENARIOS = ["normal", "normal", "hot", "hot", "high_rh", "high_rh", "low_co2", "low_co2", "bad_mix", "bad_mix"]


def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def epsilon_by_episode(episode: int) -> float:
    return max(config.EPSILON_FINAL, config.EPSILON_START * (config.EPSILON_DECAY ** episode))


def run_episode(env: IndoorFarmingEnv, agent: DQNAgent, replay_buffer=None, epsilon: float = 0.0, episode_idx: int = 0, train: bool = False, scenario: str = None):
    raw_state = env.reset(scenario=scenario)
    state_norm = normalize_state(raw_state)
    step_logs = []
    losses = []

    for step in range(config.STEPS_PER_EPISODE):
        valid_actions = env.get_valid_actions()
        requested_action = agent.select_action(state_norm, valid_actions, epsilon)
        next_raw_state, reward, done, info = env.step(requested_action)
        next_state_norm = normalize_state(next_raw_state)

        # Untuk learning, pakai final_action yang benar-benar diterapkan environment.
        final_action = int(info["final_action"])

        if train and replay_buffer is not None:
            replay_buffer.push(state_norm, final_action, reward, next_state_norm, done)
            loss = agent.train_step(replay_buffer)
            if loss is not None:
                losses.append(loss)

        # Simpan step log ringkas untuk metrik.
        row = step_log_row(episode_idx, step, next_raw_state, info, info)
        step_logs.append(row)

        state_norm = next_state_norm
        if done:
            break

    metrics = compute_episode_metrics(step_logs)
    metrics["avg_loss"] = float(np.mean(losses)) if losses else 0.0
    return metrics, step_logs


def evaluate(agent: DQNAgent, episode_idx: int):
    eval_metrics = []
    all_step_logs = []
    for i, scenario in enumerate(EVAL_SCENARIOS[:config.EVAL_EPISODES]):
        env = IndoorFarmingEnv(seed=config.RANDOM_SEED + 10_000 + episode_idx + i)
        metrics, step_logs = run_episode(env, agent, epsilon=0.0, episode_idx=episode_idx, train=False, scenario=scenario)
        metrics["scenario"] = scenario
        eval_metrics.append(metrics)
        all_step_logs.extend(step_logs)

    avg = average_metrics(eval_metrics)
    avg["model_score"] = model_selection_score(avg)
    return avg, all_step_logs


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--episodes", type=int, default=config.EPISODES, help="Jumlah episode training")
    parser.add_argument("--seed", type=int, default=config.RANDOM_SEED, help="Random seed")
    args = parser.parse_args()

    set_seed(args.seed)
    ensure_dirs()
    save_configs()

    env = IndoorFarmingEnv(seed=args.seed)
    agent = DQNAgent()
    replay_buffer = ReplayBuffer(config.REPLAY_BUFFER_SIZE)

    best_score = -1e18
    best_episode = -1

    training_log_path = f"{config.LOG_DIR}/training_episode_log.csv"
    evaluation_log_path = f"{config.LOG_DIR}/evaluation_log.csv"
    evaluation_step_log_path = f"{config.LOG_DIR}/evaluation_step_log.csv"

    print(f"Training dimulai. Device: {agent.device}")
    print(f"Episode: {args.episodes}, Step/episode: {config.STEPS_PER_EPISODE}")

    for episode in range(args.episodes):
        epsilon = epsilon_by_episode(episode)
        metrics, _ = run_episode(env, agent, replay_buffer, epsilon=epsilon, episode_idx=episode, train=True)

        train_row = {
            "episode": episode,
            "epsilon": epsilon,
            "replay_size": len(replay_buffer),
            **metrics,
        }
        append_csv(training_log_path, train_row)

        if episode % 10 == 0:
            print(
                f"Ep {episode:04d} | eps={epsilon:.3f} | "
                f"reward={metrics.get('total_reward', 0):.1f} | "
                f"T%={metrics.get('temp_ideal_pct', 0):.1f} | "
                f"RH%={metrics.get('rh_ideal_pct', 0):.1f} | "
                f"CO2%={metrics.get('co2_ideal_pct', 0):.1f} | "
                f"unsafe={metrics.get('unsafe_count', 0)}"
            )

        # Evaluasi dan model selection.
        if episode > 0 and episode % config.EVALUATION_INTERVAL == 0:
            eval_avg, eval_steps = evaluate(agent, episode)
            score = eval_avg["model_score"]
            is_best = score > best_score
            if is_best:
                best_score = score
                best_episode = episode
                agent.save_model(f"{config.MODEL_DIR}/best_model.pth")

            # Simpan checkpoint berkala.
            agent.save_model(f"{config.MODEL_DIR}/checkpoints/model_ep_{episode}.pth")

            eval_row = {
                "episode": episode,
                "eval_avg_reward": eval_avg.get("avg_reward", 0.0),
                "eval_total_reward": eval_avg.get("total_reward", 0.0),
                "eval_temp_ideal_pct": eval_avg.get("temp_ideal_pct", 0.0),
                "eval_rh_ideal_pct": eval_avg.get("rh_ideal_pct", 0.0),
                "eval_co2_ideal_pct": eval_avg.get("co2_ideal_pct", 0.0),
                "eval_total_energy_kwh": eval_avg.get("total_energy_kwh", 0.0),
                "eval_switch_count": eval_avg.get("switch_count_total", 0.0),
                "eval_unsafe_count": eval_avg.get("unsafe_count", 0.0),
                "model_score": score,
                "is_best_model": is_best,
                "best_episode": best_episode,
            }
            append_csv(evaluation_log_path, eval_row)

            # Step log evaluasi terakhir ditulis ulang agar ukurannya tidak terlalu besar.
            write_csv(evaluation_step_log_path, eval_steps)

            print(
                f"EVAL ep={episode} | score={score:.2f} | best={best_score:.2f} | "
                f"T%={eval_row['eval_temp_ideal_pct']:.1f} | "
                f"RH%={eval_row['eval_rh_ideal_pct']:.1f} | "
                f"CO2%={eval_row['eval_co2_ideal_pct']:.1f} | "
                f"unsafe={eval_row['eval_unsafe_count']:.1f} | is_best={is_best}"
            )

    agent.save_model(f"{config.MODEL_DIR}/last_model.pth")
    print("Training selesai.")
    print(f"Best episode: {best_episode}, best score: {best_score:.2f}")
    print(f"Model tersimpan di: {config.MODEL_DIR}")


if __name__ == "__main__":
    main()

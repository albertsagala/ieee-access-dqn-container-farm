"""
- Epsilon-greedy dengan action masking
- Target network
- Huber loss
"""
import random
from typing import List

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim

import config
from constraints import apply_action_mask
from dqn_model import DQNModel


class DQNAgent:
    def __init__(self, device: str = None):
        self.device = torch.device(device if device is not None else ("cuda" if torch.cuda.is_available() else "cpu"))
        self.policy_net = DQNModel(config.STATE_SIZE, config.ACTION_SIZE).to(self.device)
        self.target_net = DQNModel(config.STATE_SIZE, config.ACTION_SIZE).to(self.device)
        self.target_net.load_state_dict(self.policy_net.state_dict())
        self.target_net.eval()

        self.optimizer = optim.Adam(self.policy_net.parameters(), lr=config.LEARNING_RATE)
        self.loss_fn = nn.SmoothL1Loss()  # Huber loss
        self.train_steps = 0

    def select_action(self, state_norm: np.ndarray, valid_actions: List[int], epsilon: float) -> int:
        """Pilih action. Saat random pun tetap hanya dari valid_actions."""
        if not valid_actions:
            raise ValueError("valid_actions kosong. Cek action masking.")

        if random.random() < epsilon:
            return int(random.choice(valid_actions))

        self.policy_net.eval()
        with torch.no_grad():
            state_tensor = torch.tensor(state_norm, dtype=torch.float32, device=self.device).unsqueeze(0)
            q_values = self.policy_net(state_tensor).cpu().numpy()[0]
            masked_q = apply_action_mask(q_values, valid_actions)
            return int(np.argmax(masked_q))

    def train_step(self, replay_buffer):
        if len(replay_buffer) < config.MIN_REPLAY_SIZE:
            return None
        if len(replay_buffer) < config.BATCH_SIZE:
            return None

        states, actions, rewards, next_states, dones = replay_buffer.sample(config.BATCH_SIZE)

        states_t = torch.tensor(states, dtype=torch.float32, device=self.device)
        actions_t = torch.tensor(actions, dtype=torch.long, device=self.device).unsqueeze(1)
        rewards_t = torch.tensor(rewards, dtype=torch.float32, device=self.device).unsqueeze(1)
        next_states_t = torch.tensor(next_states, dtype=torch.float32, device=self.device)
        dones_t = torch.tensor(dones, dtype=torch.float32, device=self.device).unsqueeze(1)

        self.policy_net.train()
        q_values = self.policy_net(states_t).gather(1, actions_t)

        with torch.no_grad():
            next_q_values = self.target_net(next_states_t).max(dim=1, keepdim=True)[0]
            target_q = rewards_t + config.GAMMA * next_q_values * (1.0 - dones_t)

        loss = self.loss_fn(q_values, target_q)

        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.policy_net.parameters(), config.GRADIENT_CLIP)
        self.optimizer.step()

        self.train_steps += 1
        if self.train_steps % config.TARGET_UPDATE_FREQ == 0:
            self.update_target_network()

        return float(loss.item())

    def update_target_network(self):
        self.target_net.load_state_dict(self.policy_net.state_dict())

    def save_model(self, path: str):
        torch.save({
            "model_state_dict": self.policy_net.state_dict(),
            "target_state_dict": self.target_net.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "train_steps": self.train_steps,
        }, path)

    def load_model(self, path: str):
        checkpoint = torch.load(path, map_location=self.device)
        self.policy_net.load_state_dict(checkpoint["model_state_dict"])
        if "target_state_dict" in checkpoint:
            self.target_net.load_state_dict(checkpoint["target_state_dict"])
        else:
            self.target_net.load_state_dict(self.policy_net.state_dict())
        if "optimizer_state_dict" in checkpoint:
            self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        self.train_steps = checkpoint.get("train_steps", 0)

"""
Konfigurasi deployment DQN Controller Indoor Farming.

Model:
- Model sudah dikonversi dari best_model.pth menjadi dqn_weights.npz.
- DQN menghasilkan action index 0 sampai 7.
- Payload MQTT dikirim sebagai JSON minimal:
    {"action": final_action}
- Urutan state HARUS sama dengan training:
  [T_in, RH_in, Lux_in, CO2_in, T_out, RH_out, Lux_out, AC, H, C, L]

Catatan penting:
- Sensor indoor tetap wajib tersedia.
- Sensor outdoor boleh memakai fallback jika node outdoor mati.
- DQN tetap menjadi pengambil keputusan utama.
- Safety hanya dipakai sebagai hard action masking dan anti-short-cycle AC.
- AC ON block hanya diterapkan saat lampu OFF.
"""

import os

# =========================================================
# Kontrol utama
# =========================================================
CONTROL_INTERVAL_SECONDS = 600  # 10 menit
INTERVAL_SECONDS = CONTROL_INTERVAL_SECONDS  # alias untuk kompatibilitas

MODEL_PATH = "model/dqn_weights.npz"
LOG_PATH = "logs/dqn_deploy_log.csv"

STATE_SIZE = 11
ACTION_SIZE = 8

# Jika program baru pertama kali jalan dan belum ada runtime state.
# Action 0 = semua aktuator kontrol OFF.
INITIAL_ACTION_INDEX = 0

# Durasi awal dalam satuan step.
# 1 step = 10 menit.
INITIAL_DURATIONS = {
    "ac": 1,
    "h": 1,
    "co2": 1,
}

# =========================================================
# Konfigurasi InfluxDB
# =========================================================
# Disarankan isi token lewat environment variable atau service systemd.
#
# Contoh:
# export INFLUX_TOKEN="token_kamu"
# export INFLUX_ORG="IT Del"
# export INFLUX_URL="http://INFLUXDB_HOST:8086"
#
# PENTING:
# Ganti placeholder token di bawah dengan token asli kamu.
# Jangan biarkan "ISI_TOKEN_ASLI_KAMU_DI_SINI", karena akan menyebabkan 401 Unauthorized.

INFLUX_URL = os.getenv("INFLUX_URL", "http://localhost:8086")
INFLUX_TOKEN = os.getenv("INFLUX_TOKEN", "")
INFLUX_ORG = os.getenv("INFLUX_ORG", "IT Del")
INFLUX_BUCKET = os.getenv("INFLUX_BUCKET", "Monitoring")
INFLUX_MEASUREMENT = os.getenv("INFLUX_MEASUREMENT", "mqtt_consumer")

# Alias agar cocok dengan beberapa versi kode
INFLUXDB_URL = INFLUX_URL
INFLUXDB_TOKEN = INFLUX_TOKEN
INFLUXDB_ORG = INFLUX_ORG
INFLUXDB_BUCKET = INFLUX_BUCKET
INFLUXDB_MEASUREMENT = INFLUX_MEASUREMENT
MEASUREMENT_STATE = INFLUX_MEASUREMENT

# Rentang pencarian data terbaru.
# Kalau sensor kadang terlambat masuk, bisa naikkan ke 15 atau 30.
INFLUX_LOOKBACK_MINUTES = int(os.getenv("INFLUX_LOOKBACK_MINUTES", "30"))

# =========================================================
# Fallback sensor outdoor
# =========================================================
# Ini solusi saat node outdoor mati / tidak mengirim data ke InfluxDB.
#
# Prinsip:
# - Sensor indoor tetap wajib tersedia.
# - Sensor outdoor boleh memakai nilai default sementara.
# - Dengan ini DQN tetap bisa membentuk state 11 fitur dan kontrol tidak berhenti.
#
# Outdoor hanya variabel pendukung. Variabel utama kendali tetap:
# T_in, RH_in, CO2_in, Lux_in, status aktuator, dan lampu.

ALLOW_SENSOR_DEFAULTS = True

# Sensor yang boleh memakai fallback.
# Jangan masukkan T_in, RH_in, CO2_in, Lux_in ke sini.
SENSOR_OPTIONAL_KEYS = [
    "T_out",
    "RH_out",
    "Lux_out",
]

SENSOR_DEFAULTS = {
    "T_out": 28.0,     # fallback suhu outdoor saat node outdoor mati
    "RH_out": 85.0,    # fallback RH outdoor saat node outdoor mati
    "Lux_out": 0.0,    # fallback lux outdoor saat node outdoor mati
}

# Mode log fallback.
# Jika True, sensor_reader sebaiknya menampilkan warning ketika fallback dipakai.
PRINT_SENSOR_FALLBACK_WARNING = True

# =========================================================
# Topic sensor sesuai struktur InfluxDB
# =========================================================
TOPIC_NODE14 = "sensors/node-14/data"          # T_in dan RH_in
TOPIC_NODE15 = "sensors/node-15/data"          # CO2_in
TOPIC_NODE01 = "sensors/node-01/data"          # Lux_in / lamp lux
TOPIC_OUTDOOR = "sensors/node-outdoor/data"    # T_out, RH_out, Lux_out

# Topic power/status aktuator
TOPIC_AC_POWER = "bardi/device_1/power"
TOPIC_HUM_POWER = "bardi/device_2/power"
TOPIC_CO2_POWER = "bardi/device_3_tuya/power"
TOPIC_LAMP_POWER = "bardi/device_4/power"

# Field sensor
FIELD_TEMPERATURE = "temperature"
FIELD_HUMIDITY = "humidity"
FIELD_LUX = "lux"
FIELD_CO2 = "co2_raw"

# Field status/power aktuator
FIELD_POWER = "power_w"
FIELD_STATUS = "status"
FIELD_AC_CURRENT = "current_a"

# =========================================================
# Konfigurasi MQTT
# =========================================================
# MQTT_HOST sama dengan MQTT_BROKER.
# Broker aktuator kamu berada di MQTT_BROKER_HOST.

MQTT_HOST = os.getenv("MQTT_HOST", "localhost")
MQTT_BROKER = MQTT_HOST  # alias

MQTT_PORT = int(os.getenv("MQTT_PORT", "1883"))
MQTT_TOPIC = os.getenv("MQTT_TOPIC", "actuator/command")
MQTT_QOS = int(os.getenv("MQTT_QOS", "1"))
MQTT_RETAIN = False
MQTT_CLIENT_ID = os.getenv("MQTT_CLIENT_ID", "dqn_controller_jetson")

# DQN tetap menghasilkan index action 0-7.
# Receiver aktuator membaca JSON: {"action": final_action}
MQTT_PAYLOAD_ONLY_ACTION_INDEX = False
MQTT_PAYLOAD_FORMAT = "json_action_only"

# =========================================================
# Jadwal lampu / photoperiod
# =========================================================
LAMP_ON_HOUR = 6.0
LAMP_OFF_HOUR = 22.0

# Pilihan sumber status lampu:
# - "influx_status": pakai status lampu dari bardi/device_4/power
# - "schedule": pakai jadwal 06.00-22.00
# - "lux": pakai Lux_in
LAMP_STATUS_SOURCE = "influx_status"
LAMP_LUX_THRESHOLD = 1000.0

# =========================================================
# Normalisasi state, harus sama dengan training terbaru
# =========================================================
NORM = {
    "T_in": (16.0, 35.0),
    "RH_in": (35.0, 100.0),
    "Lux_in": (0.0, 3000.0),
    "CO2_in": (400.0, 1300.0),
    "T_out": (15.0, 45.0),
    "RH_out": (30.0, 100.0),
    "Lux_out": (0.0, 55000.0),
}

# =========================================================
# Batas ideal untuk evaluasi
# =========================================================
# Catatan:
# - Batas ini dipakai untuk analisis/evaluasi.
# - Bukan rule utama yang memaksa action DQN.

TEMP_IDEAL_MIN = 20.0
TEMP_IDEAL_MAX = 24.0

RH_IDEAL_MIN = 60.0
RH_IDEAL_MAX = 70.0

CO2_IDEAL_MIN = 800.0
CO2_IDEAL_MAX = 1000.0

# =========================================================
# Mode safety deployment
# =========================================================
# DQN tetap memilih action berdasarkan Q-value.
# Safety hanya membuang action yang tidak valid.

SAFETY_MODE = "dqn_dominant_hard_action_masking_lamp_off_ac_block"

# =========================================================
# Hard action masking AC hanya saat lampu OFF
# =========================================================
# Tujuan:
# - Saat lampu OFF / malam / pagi: AC ON diblokir jika suhu sudah cukup rendah.
# - Saat lampu ON / siang: aturan blokir AC berdasarkan suhu rendah tidak diterapkan.
#
# Ini tetap action masking, bukan rule-based control.
# DQN tetap memilih action berdasarkan Q-value dari action yang valid.

ENABLE_AC_ON_BLOCK_WHEN_LAMP_OFF_ONLY = True

# Jika lampu OFF, AC ON diblokir pada suhu <= 22.5 C.
AC_ON_BLOCK_TEMP_LAMP_OFF = 22.5

# Variabel lama/fallback untuk kompatibilitas.
# Tidak dipakai jika ENABLE_AC_ON_BLOCK_WHEN_LAMP_OFF_ONLY = True.
AC_ON_BLOCK_TEMP = 22.5

# Emergency guardrail.
# Jika suhu sudah sangat tinggi, action tanpa AC dapat diblokir.
# Ini bukan setpoint rule 24 C, melainkan batas darurat.

ENABLE_EMERGENCY_AC_ON_MASK = True
TEMP_EMERGENCY_AC_ON = 28.0

# =========================================================
# Hard action masking humidifier
# =========================================================
# Humidifier tidak boleh ON jika RH sudah terlalu tinggi.
# Nilai 80 dipakai sebagai guardrail, bukan target ideal 70%.

HUMIDIFIER_ON_BLOCK_RH = 80.0

# =========================================================
# Hard action masking CO2
# =========================================================
# CO2 tidak boleh ON saat lampu OFF.
# CO2 juga tidak boleh ON jika konsentrasi sudah tinggi.

CO2_ON_BLOCK_WHEN_LAMP_OFF = True
CO2_ON_BLOCK_HIGH = 1000.0

# =========================================================
# Batas unsafe / validasi data
# =========================================================
TEMP_UNSAFE_LOW = 17.0
TEMP_UNSAFE_HIGH = 28.0

RH_UNSAFE_LOW = 40.0
RH_UNSAFE_HIGH = 95.0

CO2_UNSAFE_HIGH = 1200.0
CO2_UNSAFE_LOW_WITH_LAMP = 550.0

# Jika data di luar batas ini, program tidak publish action.
# Outdoor tetap divalidasi setelah fallback diterapkan.
SENSOR_VALID_RANGE = {
    "T_in": (0.0, 50.0),
    "RH_in": (0.0, 100.0),
    "CO2_in": (300.0, 3000.0),
    "Lux_in": (0.0, 100000.0),
    "T_out": (0.0, 60.0),
    "RH_out": (0.0, 100.0),
    "Lux_out": (0.0, 120000.0),
    "AC": (0, 1),
    "H": (0, 1),
    "C": (0, 1),
    "L": (0, 1),
}

# =========================================================
# Threshold pembacaan status aktuator
# =========================================================
# AC dibaca dari current_a pada topic bardi/device_1/power.

AC_ON_CURRENT_THRESHOLD = 0.05

# Fallback jika status field tidak terbaca
HUM_ON_POWER_THRESHOLD = 2.0
CO2_ON_POWER_THRESHOLD = 0.1
LAMP_ON_POWER_THRESHOLD = 10.0
LAMP_LUX_ON_THRESHOLD = 1000.0

# =========================================================
# Anti-short-cycle AC
# =========================================================
# Ini tetap action masking, bukan rule-based control.
# Tujuannya mengurangi switching AC dan mengurangi energi start-stop.
#
# Dengan interval 10 menit:
# - MIN_ON_STEPS["ac"] tidak dipakai untuk menahan AC ON terlalu lama
#   pada safety_controller versi terbaru.
# - MIN_OFF_STEPS["ac"] dipakai untuk menahan AC OFF minimal 30 menit,
#   kecuali suhu sudah melewati AC_MIN_OFF_BYPASS_TEMP.

ENABLE_AC_ANTI_SHORT_CYCLE = True

MIN_ON_STEPS = {
    "ac": 2,     # disimpan untuk kompatibilitas / training note
    "h": 1,
    "co2": 1,
}

MIN_OFF_STEPS = {
    "ac": 3,     # 3 step x 10 menit = 30 menit
    "h": 2,
    "co2": 1,
}

# Bypass anti-short-cycle AC.
# Jika AC baru OFF tetapi suhu sudah tinggi, AC boleh ON.
AC_MIN_OFF_BYPASS_TEMP = 24.8

# Disimpan untuk kompatibilitas.
# Pada safety_controller hard masking terbaru, AC ON -> OFF tidak ditahan.
AC_MIN_ON_BYPASS_TEMP = 20.5

# =========================================================
# Variabel lama untuk kompatibilitas
# =========================================================
# Catatan:
# Variabel di bawah ini TIDAK digunakan sebagai forcing oleh
# safety_controller.py versi hard action masking.
# Dibiarkan agar file lain yang mungkin masih import tidak error.

TEMP_AC_OFF_LIMIT = 20.5
TEMP_AC_ON_LIMIT = 23.8

RH_H_ON_LIMIT = 50.0
RH_H_OFF_LIMIT = 70.0

CO2_FORCE_ON_LIMIT = 500.0
CO2_FORCE_OFF_LIMIT = 1000.0
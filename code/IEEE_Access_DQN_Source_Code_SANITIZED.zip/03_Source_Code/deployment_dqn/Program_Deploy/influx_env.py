# -*- coding: utf-8 -*-
"""
influx_env.py

Pembaca data InfluxDB untuk DQN deployment terbaru.

Fungsi:
- Membaca sensor dari topic InfluxDB asli:
  sensors/node-14/data
  sensors/node-15/data
  sensors/node-01/data
  sensors/node-outdoor/data

- Membaca status aktuator dari topic:
  bardi/device_1/power
  bardi/device_2/power
  bardi/device_3_tuya/power
  bardi/device_4/power

- Menghasilkan state deployment terbaru:
  [T_in, RH_in, Lux_in, CO2_in, T_out, RH_out, Lux_out, AC, H, C, L]

Catatan:
- File ini TIDAK memakai state lama berbasis power.
- Status aktuator dikonversi menjadi biner 0/1.
"""

from datetime import datetime

import influxdb_client

import config_deploy as config


class InfluxEnv(object):
    def __init__(self):
        self.client = influxdb_client.InfluxDBClient(
            url=config.INFLUX_URL,
            token=config.INFLUX_TOKEN,
            org=config.INFLUX_ORG,
            timeout=10000,
        )
        self.query_api = self.client.query_api()

        self.bucket = config.INFLUX_BUCKET
        self.org = config.INFLUX_ORG
        self.measurement = config.INFLUX_MEASUREMENT

        self.range_start = "-{}m".format(int(config.INFLUX_LOOKBACK_MINUTES))
        self.window_period = "1m"

        self.last_raw = None

        self.ac_on = False
        self.hum_on = False
        self.co2_on = False
        self.lamp_on = False

    # =========================================================
    # Utility
    # =========================================================

    def close(self):
        try:
            self.client.close()
        except Exception:
            pass

    def _escape_flux_string(self, value):
        return str(value).replace('"', '\\"')

    def _safe_float(self, value, fallback=None):
        try:
            if value is None:
                if fallback is None:
                    return None
                return float(fallback)
            return float(value)
        except Exception:
            if fallback is None:
                return None
            return float(fallback)

    def _status_to_bool(self, value, fallback=False):
        """
        Konversi nilai status dari Influx menjadi boolean.

        Mendukung:
        - 1 / 0
        - 1.0 / 0.0
        - True / False
        - "ON" / "OFF"
        - "on" / "off"
        - "true" / "false"
        - "1" / "0"
        """
        if value is None:
            return bool(fallback)

        if isinstance(value, bool):
            return bool(value)

        if isinstance(value, (int, float)):
            return float(value) > 0.5

        try:
            text = str(value).strip().lower()

            if text in ["1", "on", "true", "yes", "open", "aktif", "active"]:
                return True

            if text in ["0", "off", "false", "no", "close", "mati", "inactive"]:
                return False

            return float(text) > 0.5

        except Exception:
            return bool(fallback)

    # =========================================================
    # Query helper
    # =========================================================

    def _query_last_value_by_topic(self, field, topic):
        """
        Query nilai terakhir berdasarkan tag topic dan field.
        Return bisa float, bool, string, tergantung isi Influx.
        """
        bucket = self._escape_flux_string(self.bucket)
        measurement = self._escape_flux_string(self.measurement)
        field = self._escape_flux_string(field)
        topic = self._escape_flux_string(topic)

        query = '''
from(bucket: "{bucket}")
  |> range(start: {range_start})
  |> filter(fn: (r) => r["_measurement"] == "{measurement}")
  |> filter(fn: (r) => r["topic"] == "{topic}")
  |> filter(fn: (r) => r["_field"] == "{field}")
  |> last()
'''.format(
            bucket=bucket,
            range_start=self.range_start,
            measurement=measurement,
            topic=topic,
            field=field,
        )

        tables = self.query_api.query(query=query, org=self.org)

        for table in tables:
            for record in table.records:
                return record.get_value()

        return None

    def _query_mean_numeric_by_topic(self, field, topic):
        """
        Query mean numeric dalam window, lalu ambil nilai terakhir.
        Cocok untuk temperature, humidity, lux, CO2.
        """
        bucket = self._escape_flux_string(self.bucket)
        measurement = self._escape_flux_string(self.measurement)
        field = self._escape_flux_string(field)
        topic = self._escape_flux_string(topic)

        query = '''
from(bucket: "{bucket}")
  |> range(start: {range_start})
  |> filter(fn: (r) => r["_measurement"] == "{measurement}")
  |> filter(fn: (r) => r["topic"] == "{topic}")
  |> filter(fn: (r) => r["_field"] == "{field}")
  |> aggregateWindow(every: {window_period}, fn: mean, createEmpty: false)
  |> last()
'''.format(
            bucket=bucket,
            range_start=self.range_start,
            measurement=measurement,
            topic=topic,
            field=field,
            window_period=self.window_period,
        )

        tables = self.query_api.query(query=query, org=self.org)

        for table in tables:
            for record in table.records:
                return self._safe_float(record.get_value(), fallback=None)

        return None

    def _query_last_numeric_by_topic(self, field, topic):
        value = self._query_last_value_by_topic(field, topic)
        return self._safe_float(value, fallback=None)

    # =========================================================
    # Read raw sensor
    # =========================================================

    def read_raw(self):
        """
        Membaca data mentah dari InfluxDB.

        Return raw:
        {
            "T_in": ...,
            "RH_in": ...,
            "Lux_in": ...,
            "CO2_in": ...,
            "T_out": ...,
            "RH_out": ...,
            "Lux_out": ...,
            "P_AC": ...,
            "P_Hum": ...,
            "P_CO2": ...,
            "P_Light": ...,
            "I_AC": ...,
            "Status_Hum": ...,
            "Status_CO2": ...,
            "Status_Light": ...
        }
        """

        raw = {}

        # Indoor sensor
        raw["T_in"] = self._query_mean_numeric_by_topic(
            config.FIELD_TEMPERATURE,
            config.TOPIC_NODE14,
        )
        raw["RH_in"] = self._query_mean_numeric_by_topic(
            config.FIELD_HUMIDITY,
            config.TOPIC_NODE14,
        )
        raw["Lux_in"] = self._query_mean_numeric_by_topic(
            config.FIELD_LUX,
            config.TOPIC_NODE01,
        )
        raw["CO2_in"] = self._query_mean_numeric_by_topic(
            config.FIELD_CO2,
            config.TOPIC_NODE15,
        )

        # Outdoor sensor
        raw["T_out"] = self._query_mean_numeric_by_topic(
            config.FIELD_TEMPERATURE,
            config.TOPIC_OUTDOOR,
        )
        raw["RH_out"] = self._query_mean_numeric_by_topic(
            config.FIELD_HUMIDITY,
            config.TOPIC_OUTDOOR,
        )
        raw["Lux_out"] = self._query_mean_numeric_by_topic(
            config.FIELD_LUX,
            config.TOPIC_OUTDOOR,
        )

        # Power/status diagnostic
        raw["P_AC"] = self._query_last_numeric_by_topic(
            config.FIELD_POWER,
            config.TOPIC_AC_POWER,
        )
        raw["P_Hum"] = self._query_last_numeric_by_topic(
            config.FIELD_POWER,
            config.TOPIC_HUM_POWER,
        )
        raw["P_CO2"] = self._query_last_numeric_by_topic(
            config.FIELD_POWER,
            config.TOPIC_CO2_POWER,
        )
        raw["P_Light"] = self._query_last_numeric_by_topic(
            config.FIELD_POWER,
            config.TOPIC_LAMP_POWER,
        )

        # Status aktuator
        raw["I_AC"] = self._query_last_numeric_by_topic(
            config.FIELD_AC_CURRENT,
            config.TOPIC_AC_POWER,
        )
        raw["Status_Hum"] = self._query_last_value_by_topic(
            config.FIELD_STATUS,
            config.TOPIC_HUM_POWER,
        )
        raw["Status_CO2"] = self._query_last_value_by_topic(
            config.FIELD_STATUS,
            config.TOPIC_CO2_POWER,
        )
        raw["Status_Light"] = self._query_last_value_by_topic(
            config.FIELD_STATUS,
            config.TOPIC_LAMP_POWER,
        )

        self.last_raw = dict(raw)

        self._sync_status_from_raw(raw)

        return raw

    # =========================================================
    # Status actuator
    # =========================================================

    def _lamp_by_schedule(self):
        now = datetime.now()
        hour = now.hour + now.minute / 60.0 + now.second / 3600.0
        return config.LAMP_ON_HOUR <= hour < config.LAMP_OFF_HOUR

    def _sync_status_from_raw(self, raw):
        """
        Sinkronisasi status aktuator dari raw Influx.

        AC:
          dari current_a.

        Humidifier:
          dari field status, fallback power_w.

        CO2:
          dari field status, fallback power_w.

        Lamp:
          default dari status Influx.
          jika tidak ada, fallback ke schedule/lux/power.
        """

        # AC status dari current_a
        i_ac = self._safe_float(raw.get("I_AC"), fallback=0.0)
        self.ac_on = i_ac > float(config.AC_ON_CURRENT_THRESHOLD)

        # Humidifier status
        if raw.get("Status_Hum") is not None:
            self.hum_on = self._status_to_bool(raw.get("Status_Hum"), fallback=False)
        else:
            p_hum = self._safe_float(raw.get("P_Hum"), fallback=0.0)
            self.hum_on = p_hum > float(config.HUM_ON_POWER_THRESHOLD)

        # CO2 status
        if raw.get("Status_CO2") is not None:
            self.co2_on = self._status_to_bool(raw.get("Status_CO2"), fallback=False)
        else:
            p_co2 = self._safe_float(raw.get("P_CO2"), fallback=0.0)
            self.co2_on = p_co2 > float(config.CO2_ON_POWER_THRESHOLD)

        # Lamp status
        source = str(config.LAMP_STATUS_SOURCE).lower()

        if source == "schedule":
            self.lamp_on = self._lamp_by_schedule()

        elif source == "lux":
            lux = self._safe_float(raw.get("Lux_in"), fallback=0.0)
            self.lamp_on = lux >= float(config.LAMP_LUX_THRESHOLD)

        else:
            # Default: pakai status Influx, fallback power/lux/schedule
            if raw.get("Status_Light") is not None:
                self.lamp_on = self._status_to_bool(raw.get("Status_Light"), fallback=False)
            else:
                p_light = self._safe_float(raw.get("P_Light"), fallback=0.0)
                lux = self._safe_float(raw.get("Lux_in"), fallback=0.0)

                if p_light > float(config.LAMP_ON_POWER_THRESHOLD):
                    self.lamp_on = True
                elif lux >= float(config.LAMP_LUX_THRESHOLD):
                    self.lamp_on = True
                else:
                    self.lamp_on = self._lamp_by_schedule()

    # =========================================================
    # Final data for DQN deployment
    # =========================================================

    def read_state_data(self):
        """
        Return data yang langsung cocok dengan state terbaru:
        [T_in, RH_in, Lux_in, CO2_in, T_out, RH_out, Lux_out, AC, H, C, L]
        """

        raw = self.read_raw()

        required = [
            "T_in",
            "RH_in",
            "Lux_in",
            "CO2_in",
            "T_out",
            "RH_out",
            "Lux_out",
        ]

        missing = []
        for key in required:
            if raw.get(key) is None:
                missing.append(key)

        if missing:
            raise RuntimeError(
                "Data sensor tidak ditemukan dari InfluxDB: {}".format(
                    ", ".join(missing)
                )
            )

        data = {
            "T_in": float(raw["T_in"]),
            "RH_in": float(raw["RH_in"]),
            "Lux_in": float(raw["Lux_in"]),
            "CO2_in": float(raw["CO2_in"]),
            "T_out": float(raw["T_out"]),
            "RH_out": float(raw["RH_out"]),
            "Lux_out": float(raw["Lux_out"]),

            # Status biner terbaru, sesuai state training
            "AC": 1 if self.ac_on else 0,
            "H": 1 if self.hum_on else 0,
            "C": 1 if self.co2_on else 0,
            "L": 1 if self.lamp_on else 0,

            # Diagnostic tambahan
            "P_AC": self._safe_float(raw.get("P_AC"), fallback=0.0),
            "P_Hum": self._safe_float(raw.get("P_Hum"), fallback=0.0),
            "P_CO2": self._safe_float(raw.get("P_CO2"), fallback=0.0),
            "P_Light": self._safe_float(raw.get("P_Light"), fallback=0.0),
            "I_AC": self._safe_float(raw.get("I_AC"), fallback=0.0),
            "Status_Hum": raw.get("Status_Hum"),
            "Status_CO2": raw.get("Status_CO2"),
            "Status_Light": raw.get("Status_Light"),
        }

        return data
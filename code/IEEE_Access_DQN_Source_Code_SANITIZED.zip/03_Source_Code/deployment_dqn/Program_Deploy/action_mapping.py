"""
Mapping action DQN modifikasi terbaru.

Output utama model/deploy tetap berupa indeks action 0-7.
Action tersebut kemudian diterjemahkan menjadi kombinasi aktuator.
"""

ACTION_MAP = {
    0: {"ac": 0, "h": 0, "co2": 0, "label": "ALL_OFF"},
    1: {"ac": 1, "h": 0, "co2": 0, "label": "AC_ON"},
    2: {"ac": 0, "h": 1, "co2": 0, "label": "H_ON"},
    3: {"ac": 0, "h": 0, "co2": 1, "label": "CO2_ON"},
    4: {"ac": 1, "h": 1, "co2": 0, "label": "AC_H_ON"},
    5: {"ac": 1, "h": 0, "co2": 1, "label": "AC_CO2_ON"},
    6: {"ac": 0, "h": 1, "co2": 1, "label": "H_CO2_ON"},
    7: {"ac": 1, "h": 1, "co2": 1, "label": "AC_H_CO2_ON"},
}


def all_actions():
    return list(ACTION_MAP.keys())


def decode_action(action_index):
    """Mengubah indeks action menjadi status aktuator."""
    idx = int(action_index)
    if idx not in ACTION_MAP:
        raise ValueError("Action index tidak valid: {}".format(action_index))
    item = ACTION_MAP[idx]
    return {"ac": int(item["ac"]), "h": int(item["h"]), "co2": int(item["co2"])}


def encode_action(ac, h, co2):
    """Mengubah status aktuator menjadi indeks action 0-7."""
    ac = int(ac)
    h = int(h)
    co2 = int(co2)
    for idx, item in ACTION_MAP.items():
        if int(item["ac"]) == ac and int(item["h"]) == h and int(item["co2"]) == co2:
            return int(idx)
    raise ValueError("Kombinasi aktuator tidak ada di ACTION_MAP: ac={}, h={}, co2={}".format(ac, h, co2))


def action_label(action_index):
    return ACTION_MAP[int(action_index)]["label"]

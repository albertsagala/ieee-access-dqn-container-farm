"""
Safety controller deploy.

Versi revisi:
- DQN tetap menjadi pengambil keputusan utama.
- Safety hanya melakukan hard action masking.
- Tidak ada target-based forcing seperti:
    T > 23.8  -> AC wajib ON
    T <= 20.5 -> AC wajib OFF
    RH >= 70  -> humidifier wajib OFF
    CO2 <= 500 -> CO2 wajib ON

Revisi penting:
- AC_ON_BLOCK_TEMP dibuat dinamis berdasarkan status lampu.
- Saat lampu OFF, AC ON lebih ketat diblokir agar tidak overcooling pagi/malam.
- Saat lampu ON, AC ON lebih longgar agar suhu siang tidak terlalu panas.

Hard masking yang aktif:
- AC ON diblokir jika T <= batas dinamis AC.
- Action tanpa AC diblokir jika suhu emergency tinggi dan emergency mask aktif.
- Humidifier ON diblokir jika RH terlalu tinggi.
- CO2 ON diblokir jika lampu OFF.
- CO2 ON diblokir jika CO2 sudah tinggi.
- Anti-short-cycle AC untuk mengurangi switching.

Output akhir tetap action index 0-7.
"""

import numpy as np

import config_deploy as config
from action_mapping import all_actions, decode_action, encode_action


class SafetyController(object):
    def __init__(self, current_status, durations=None):
        self.current_status = {
            "ac": int(current_status.get("ac", 0)),
            "h": int(current_status.get("h", 0)),
            "co2": int(current_status.get("co2", 0)),
        }

        if durations is None:
            durations = dict(config.INITIAL_DURATIONS)

        self.durations = {
            "ac": int(durations.get("ac", 1)),
            "h": int(durations.get("h", 1)),
            "co2": int(durations.get("co2", 1)),
        }

        # Penanda agar sync pertama dari sensor/Influx mereset duration.
        self.first_actual_sync = True

    # =========================================================
    # Sinkron status aktual dari sensor
    # =========================================================

    def sync_actual_status(self, actual_status):
        """
        Sinkronisasi status aktual aktuator dari sensor/Influx.

        - Pada sync pertama, status internal disesuaikan dengan status aktual
          dan duration direset menjadi 1.
        - Setelah sync pertama, jika status aktual berubah, duration aktuator
          terkait direset menjadi 1.
        - Jika status sama, duration tidak ditambah di sini.
          Duration hanya ditambah setelah publish sukses.
        """

        actual = {
            "ac": int(actual_status.get("ac", self.current_status.get("ac", 0))),
            "h": int(actual_status.get("h", self.current_status.get("h", 0))),
            "co2": int(actual_status.get("co2", self.current_status.get("co2", 0))),
        }

        if self.first_actual_sync:
            self.current_status = {
                "ac": int(actual["ac"]),
                "h": int(actual["h"]),
                "co2": int(actual["co2"]),
            }

            self.durations = {
                "ac": 1,
                "h": 1,
                "co2": 1,
            }

            self.first_actual_sync = False
            return

        for key in ["ac", "h", "co2"]:
            if int(actual[key]) != int(self.current_status[key]):
                self.current_status[key] = int(actual[key])
                self.durations[key] = 1

    # =========================================================
    # Helper status
    # =========================================================

    def _status_value(self, status, key):
        """
        Mengambil nilai status hasil decode_action.

        Dibuat lebih aman jika key humidifier pada action_mapping
        suatu saat bernama 'h' atau 'humidifier'.
        """

        if key == "h":
            return int(status.get("h", status.get("humidifier", 0)))

        return int(status.get(key, 0))

    def _normalize_status(self, status):
        return {
            "ac": int(self._status_value(status, "ac")),
            "h": int(self._status_value(status, "h")),
            "co2": int(self._status_value(status, "co2")),
        }

    # =========================================================
    # Helper AC dynamic masking
    # =========================================================

    def _get_ac_on_block_temp(self, lamp):
        """
        Menentukan batas blokir AC ON berdasarkan status lampu.

        Jika lampu OFF:
            batas lebih tinggi, default 22.5 C,
            supaya malam/pagi tidak terlalu dingin.

        Jika lampu ON:
            batas lebih rendah, default 21.8 C,
            supaya siang AC tidak terlalu terlambat ON.
        """

        dynamic_enable = bool(
            getattr(config, "ENABLE_DYNAMIC_AC_ON_BLOCK_TEMP", False)
        )

        if dynamic_enable:
            if int(lamp) == 1:
                return float(getattr(config, "AC_ON_BLOCK_TEMP_LAMP_ON", 21.8))
            return float(getattr(config, "AC_ON_BLOCK_TEMP_LAMP_OFF", 22.5))

        return float(getattr(config, "AC_ON_BLOCK_TEMP", 22.5))

    # =========================================================
    # Hard action masking
    # =========================================================

    def _allowed_by_hard_mask(self, action_idx, state):
        """
        Mengecek apakah action boleh dipilih.

        Urutan state:
        [
            T_in, RH_in, Lux_in, CO2_in,
            T_out, RH_out, Lux_out,
            AC, H, C, L
        ]
        """

        T, RH, Lux_in, CO2, T_out, RH_out, Lux_out, ac, h, c, lamp = state

        T = float(T)
        RH = float(RH)
        CO2 = float(CO2)
        lamp = int(lamp)

        status = self._normalize_status(decode_action(int(action_idx)))

        ac_on = int(status["ac"])
        h_on = int(status["h"])
        co2_on = int(status["co2"])

        # =====================================================
        # Mask 1:
        # AC tidak boleh ON jika suhu sudah cukup rendah.
        # Batasnya dinamis:
        # - Lampu OFF: lebih ketat, default 22.5 C.
        # - Lampu ON : lebih longgar, default 21.8 C.
        # =====================================================
        ac_on_block_temp = self._get_ac_on_block_temp(lamp)

        if T <= ac_on_block_temp and ac_on == 1:
            return False

        # =====================================================
        # Mask 2:
        # AC tidak boleh ON jika suhu sudah unsafe rendah.
        # Ini guard tambahan.
        # =====================================================
        temp_unsafe_low = float(getattr(config, "TEMP_UNSAFE_LOW", 17.0))

        if T <= temp_unsafe_low and ac_on == 1:
            return False

        # =====================================================
        # Mask 3:
        # Jika suhu emergency tinggi, action tanpa AC dapat
        # diblokir. Ini bukan setpoint rule 24 C, melainkan
        # emergency guardrail.
        # =====================================================
        enable_emergency_ac = bool(
            getattr(config, "ENABLE_EMERGENCY_AC_ON_MASK", True)
        )
        temp_emergency_ac_on = float(
            getattr(config, "TEMP_EMERGENCY_AC_ON", 28.0)
        )

        if enable_emergency_ac and T >= temp_emergency_ac_on and ac_on == 0:
            return False

        # =====================================================
        # Mask 4:
        # Humidifier tidak boleh ON jika RH sudah terlalu tinggi.
        # =====================================================
        hum_block_rh = float(getattr(config, "HUMIDIFIER_ON_BLOCK_RH", 80.0))

        if RH >= hum_block_rh and h_on == 1:
            return False

        # =====================================================
        # Mask 5:
        # CO2 tidak boleh ON saat lampu OFF.
        # =====================================================
        co2_block_lamp_off = bool(
            getattr(config, "CO2_ON_BLOCK_WHEN_LAMP_OFF", True)
        )

        if co2_block_lamp_off and lamp == 0 and co2_on == 1:
            return False

        # =====================================================
        # Mask 6:
        # CO2 tidak boleh ON jika CO2 sudah tinggi.
        # =====================================================
        co2_block_high = float(getattr(config, "CO2_ON_BLOCK_HIGH", 1000.0))

        if CO2 >= co2_block_high and co2_on == 1:
            return False

        return True

    # =========================================================
    # Anti-short-cycle AC
    # =========================================================

    def _allowed_by_ac_anti_short_cycle(self, action_idx, state):
        """
        Mengurangi switching AC.

        Ini tetap action masking:
        - Tidak memaksa AC ON.
        - Tidak memaksa AC OFF berdasarkan target.
        - Hanya menahan AC agar tidak cepat hidup lagi setelah OFF.

        Dengan interval 10 menit:
        MIN_OFF_STEPS["ac"] = 3 berarti AC ditahan OFF minimal 30 menit,
        kecuali suhu sudah melewati AC_MIN_OFF_BYPASS_TEMP.
        """

        enable = bool(getattr(config, "ENABLE_AC_ANTI_SHORT_CYCLE", True))

        if not enable:
            return True

        T, RH, Lux_in, CO2, T_out, RH_out, Lux_out, ac, h, c, lamp = state
        T = float(T)

        status = self._normalize_status(decode_action(int(action_idx)))

        desired_ac = int(status["ac"])
        current_ac = int(self.current_status["ac"])
        duration_ac = int(self.durations["ac"])

        min_off_ac = int(config.MIN_OFF_STEPS.get("ac", 1))
        bypass_on_temp = float(getattr(config, "AC_MIN_OFF_BYPASS_TEMP", 24.8))

        # Jika AC sedang OFF lalu action ingin AC ON,
        # tahan ON jika durasi OFF belum cukup dan suhu belum tinggi.
        if current_ac == 0 and desired_ac == 1:
            if duration_ac < min_off_ac and T < bypass_on_temp:
                return False

        # Untuk ON -> OFF, jangan ditahan terlalu lama.
        # AC fisik terlalu kuat, jadi saat DQN ingin OFF, izinkan OFF.
        return True

    # =========================================================
    # Valid action generation
    # =========================================================

    def get_valid_actions(self, state):
        """
        Menghasilkan daftar action valid.

        Pada versi ini:
        - Tidak ada required_status_from_safety.
        - Tidak ada rule target yang memaksa AC/RH/CO2.
        - DQN tetap memilih action terbaik dari Q-value valid.
        """

        valid = []

        for action_idx in all_actions():
            action_idx = int(action_idx)

            if not self._allowed_by_hard_mask(action_idx, state):
                continue

            if not self._allowed_by_ac_anti_short_cycle(action_idx, state):
                continue

            valid.append(action_idx)

        if not valid:
            valid = [self.fallback_action(state)]

        return valid

    def fallback_action(self, state):
        """
        Fallback jika tidak ada action valid.

        Prioritas:
        1. Pertahankan status saat ini jika masih valid.
        2. Pilih action 0 = ALL OFF jika valid.
        3. Cari action pertama yang valid.
        """

        current_action = encode_action(
            int(self.current_status.get("ac", 0)),
            int(self.current_status.get("h", 0)),
            int(self.current_status.get("co2", 0)),
        )

        if self._allowed_by_hard_mask(current_action, state):
            if self._allowed_by_ac_anti_short_cycle(current_action, state):
                return int(current_action)

        if self._allowed_by_hard_mask(0, state):
            if self._allowed_by_ac_anti_short_cycle(0, state):
                return 0

        for action_idx in all_actions():
            action_idx = int(action_idx)

            if not self._allowed_by_hard_mask(action_idx, state):
                continue

            if not self._allowed_by_ac_anti_short_cycle(action_idx, state):
                continue

            return action_idx

        # Pilihan terakhir agar program tidak crash.
        return 0

    # =========================================================
    # Action selection
    # =========================================================

    def select_action_from_q(self, q_values, valid_actions):
        """
        Memilih action dengan Q-value tertinggi dari action valid.
        """

        q = np.asarray(q_values, dtype=np.float32).copy()

        masked = np.full_like(q, -1e9, dtype=np.float32)

        for idx in valid_actions:
            masked[int(idx)] = q[int(idx)]

        return int(np.argmax(masked))

    def decide_final_action(self, q_values, state):
        """
        Menentukan action akhir.

        selected_action = final_action
        karena safety tidak mengganti keputusan DQN,
        hanya membatasi action yang valid.
        """

        valid_actions = self.get_valid_actions(state)
        selected_action = self.select_action_from_q(q_values, valid_actions)

        final_action = int(selected_action)

        return selected_action, final_action, valid_actions

    # =========================================================
    # Update after publish
    # =========================================================

    def update_after_publish_success(self, final_action):
        """
        Update status internal setelah action berhasil dipublish.

        Jika status sama:
            duration += 1

        Jika status berubah:
            duration = 1
        """

        new_status = self._normalize_status(decode_action(int(final_action)))

        updated = {}

        for key in ["ac", "h", "co2"]:
            if int(new_status[key]) == int(self.current_status[key]):
                updated[key] = int(self.durations[key]) + 1
            else:
                updated[key] = 1

        self.current_status = {
            "ac": int(new_status["ac"]),
            "h": int(new_status["h"]),
            "co2": int(new_status["co2"]),
        }

        self.durations = updated

    def debug_status(self):
        return {
            "current_status": dict(self.current_status),
            "durations": dict(self.durations),
            "first_actual_sync": bool(self.first_actual_sync),
            "mode": "dqn_dominant_hard_action_masking_dynamic_ac_block",
            "dynamic_ac_block": bool(
                getattr(config, "ENABLE_DYNAMIC_AC_ON_BLOCK_TEMP", False)
            ),
            "ac_on_block_temp_lamp_on": float(
                getattr(config, "AC_ON_BLOCK_TEMP_LAMP_ON", 21.8)
            ),
            "ac_on_block_temp_lamp_off": float(
                getattr(config, "AC_ON_BLOCK_TEMP_LAMP_OFF", 22.5)
            ),
            "ac_on_block_temp_fallback": float(
                getattr(config, "AC_ON_BLOCK_TEMP", 22.5)
            ),
        }
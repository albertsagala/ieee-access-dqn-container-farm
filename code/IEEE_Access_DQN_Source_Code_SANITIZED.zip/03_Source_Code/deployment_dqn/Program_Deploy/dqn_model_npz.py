"""
Inference DQN menggunakan file NPZ.

Model training: 11 -> 64 -> 64 -> 8
Output: 8 Q-value untuk action index 0-7.

File NPZ dari export_model.py training biasanya memiliki key:
- net_0_weight, net_0_bias
- net_2_weight, net_2_bias
- net_4_weight, net_4_bias
"""
import numpy as np


class DQNModelNPZ(object):
    def __init__(self, model_path):
        self.model_path = model_path
        self.weights = np.load(model_path)
        self._load_arrays()

    def _get(self, names):
        for name in names:
            if name in self.weights:
                return self.weights[name].astype(np.float32)
        raise KeyError("Key bobot tidak ditemukan. Dicoba: {}. Key tersedia: {}".format(names, list(self.weights.keys())))

    def _load_arrays(self):
        # Kompatibel dengan hasil export_model.py dari training PyTorch Sequential.
        self.w1 = self._get(["net_0_weight", "W0", "w0", "fc1_weight"])
        self.b1 = self._get(["net_0_bias", "b0", "fc1_bias"])
        self.w2 = self._get(["net_2_weight", "W1", "w1", "fc2_weight"])
        self.b2 = self._get(["net_2_bias", "b1", "fc2_bias"])
        self.w3 = self._get(["net_4_weight", "W2", "w2", "out_weight"])
        self.b3 = self._get(["net_4_bias", "b2", "out_bias"])

    @staticmethod
    def relu(x):
        return np.maximum(x, 0.0)

    def predict_q_values(self, state_norm):
        x = np.asarray(state_norm, dtype=np.float32).reshape(1, -1)
        h1 = self.relu(np.matmul(x, self.w1.T) + self.b1)
        h2 = self.relu(np.matmul(h1, self.w2.T) + self.b2)
        q = np.matmul(h2, self.w3.T) + self.b3
        return q.reshape(-1).astype(np.float32)

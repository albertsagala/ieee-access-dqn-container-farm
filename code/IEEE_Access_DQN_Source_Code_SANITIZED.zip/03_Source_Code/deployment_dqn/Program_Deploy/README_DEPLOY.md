# DQN Deploy Controller Indoor Farming

Program ini menjalankan model DQN hasil training pada Jetson Nano untuk kontrol aktuator nyata.
Output MQTT **hanya berupa indeks action 0-7**.

## Struktur action

| Index | AC | Humidifier | CO2 |
|---:|---:|---:|---:|
| 0 | 0 | 0 | 0 |
| 1 | 1 | 0 | 0 |
| 2 | 0 | 1 | 0 |
| 3 | 0 | 0 | 1 |
| 4 | 1 | 1 | 0 |
| 5 | 1 | 0 | 1 |
| 6 | 0 | 1 | 1 |
| 7 | 1 | 1 | 1 |

## Cara pakai

1. Copy file model hasil export dari training ke:

```text
model/dqn_weights.npz
```

2. Edit konfigurasi InfluxDB dan MQTT di:

```text
config_deploy.py
```

3. Install dependency:

```bash
pip install -r requirements.txt
```

4. Jalankan deploy:

```bash
python deploy.py
```

Opsional satu iterasi:

```bash
python deploy.py --once
```

## Log

Log tersimpan di:

```text
logs/dqn_deploy_log.csv
```

## Catatan penting

- State dan normalisasi sudah disamakan dengan training.
- Model NPZ harus berasal dari arsitektur 11 -> 64 -> 64 -> 8.
- Payload MQTT hanya string angka action, misalnya `5`.

"""
Program utama deployment DQN Controller.

Model DQN menghasilkan action index 0-7.

Catatan penting:
- Receiver aktuator membaca format MQTT JSON:
    {"action": 1}
- Jadi mqtt_client.publish_action(final_action) harus mengirim JSON:
    {"action": final_action}
- Action tetap berupa indeks 0-7, hanya dibungkus JSON agar cocok dengan receiver.

Revisi penting:
- Status aktual aktuator disinkronkan melalui safety.sync_actual_status().
- Tidak memakai safety.current_status = dict(prev_status).
- Status dan duration safety disimpan ke logs/dqn_runtime_state.json.
- Kalau service direstart, status dan duration terakhir dibaca kembali.
- Counter min ON/OFF hanya di-update setelah MQTT publish sukses.

Jalankan:
    python3 deploy.py

Opsional:
    python3 deploy.py --once
    python3 deploy.py --max-steps 10
    python3 deploy.py --interval 60
"""

import argparse
import json
import os
import time
from datetime import datetime

import config_deploy as config
from action_mapping import decode_action
from dqn_model_npz import DQNModelNPZ
from sensor_reader import SensorReader, get_lamp_status
from state_normalizer import normalize_state
from safety_controller import SafetyController
from mqtt_client import MQTTActionClient
from deploy_logger import append_log, format_list


# ============================================================
# RUNTIME STATE PATH
# ============================================================

RUNTIME_STATE_PATH = "logs/dqn_runtime_state.json"


# ============================================================
# ACTION DESCRIPTION
# ============================================================

ACTION_TEXT = {
    0: "ALL OFF",
    1: "AC ON",
    2: "HUMIDIFIER ON",
    3: "CO2 ON",
    4: "AC + HUMIDIFIER ON",
    5: "AC + CO2 ON",
    6: "HUMIDIFIER + CO2 ON",
    7: "AC + HUMIDIFIER + CO2 ON",
}


def action_status_text(action_index):
    """Mengubah action index menjadi teks status aktuator."""
    try:
        status = decode_action(int(action_index))
        return "AC={} | H={} | CO2={}".format(
            int(status.get("ac", 0)),
            int(status.get("h", status.get("humidifier", 0))),
            int(status.get("co2", 0)),
        )
    except Exception:
        return "AC=? | H=? | CO2=?"


def format_q_values(q_values):
    """Format Q-value agar enak dibaca di terminal."""
    if q_values is None or len(q_values) == 0:
        return "[]"

    return "[" + ", ".join(["{:.2f}".format(float(q)) for q in q_values]) + "]"


def format_valid_actions(valid_actions):
    """Format valid action agar enak dibaca di terminal."""
    if valid_actions is None:
        return "[]"

    return "[" + ", ".join([str(int(a)) for a in valid_actions]) + "]"


def format_safety_debug(safety_debug):
    """Format status dan duration safety controller."""
    try:
        status = safety_debug.get("current_status", {})
        durations = safety_debug.get("durations", {})
        first_sync = safety_debug.get("first_actual_sync", "")

        text = (
            "status AC={} H={} CO2={} | duration AC={} H={} CO2={}"
            .format(
                int(status.get("ac", 0)),
                int(status.get("h", 0)),
                int(status.get("co2", 0)),
                int(durations.get("ac", 0)),
                int(durations.get("h", 0)),
                int(durations.get("co2", 0)),
            )
        )

        if first_sync != "":
            text += " | first_sync={}".format(bool(first_sync))

        return text

    except Exception:
        return "status/duration tidak terbaca"


# ============================================================
# RUNTIME STATE PERSISTENCE
# ============================================================

def save_runtime_state(safety):
    """
    Menyimpan status dan duration safety ke file JSON.

    File:
        logs/dqn_runtime_state.json

    Tujuan:
    - Jika service direstart, duration tidak mulai dari 1 lagi.
    - Status dan duration terakhir bisa dilanjutkan.
    """

    try:
        runtime_dir = os.path.dirname(RUNTIME_STATE_PATH)

        if runtime_dir:
            os.makedirs(runtime_dir, exist_ok=True)

        data = {
            "current_status": {
                "ac": int(safety.current_status.get("ac", 0)),
                "h": int(safety.current_status.get("h", 0)),
                "co2": int(safety.current_status.get("co2", 0)),
            },
            "durations": {
                "ac": int(safety.durations.get("ac", 1)),
                "h": int(safety.durations.get("h", 1)),
                "co2": int(safety.durations.get("co2", 1)),
            },
            "first_actual_sync": bool(getattr(safety, "first_actual_sync", False)),
            "saved_at": datetime.now().isoformat(timespec="seconds"),
        }

        tmp_path = RUNTIME_STATE_PATH + ".tmp"

        with open(tmp_path, "w") as f:
            json.dump(data, f, indent=2)

        os.rename(tmp_path, RUNTIME_STATE_PATH)

    except Exception as exc:
        print("[WARN] Gagal menyimpan runtime state: {}".format(exc))


def load_runtime_state():
    """
    Membaca status dan duration safety dari file JSON.

    Return:
    - None jika file belum ada / rusak.
    - dict jika state berhasil dibaca.
    """

    try:
        if not os.path.exists(RUNTIME_STATE_PATH):
            return None

        with open(RUNTIME_STATE_PATH, "r") as f:
            data = json.load(f)

        current_status = data.get("current_status", {})
        durations = data.get("durations", {})

        state = {
            "current_status": {
                "ac": int(current_status.get("ac", 0)),
                "h": int(current_status.get("h", 0)),
                "co2": int(current_status.get("co2", 0)),
            },
            "durations": {
                "ac": int(durations.get("ac", 1)),
                "h": int(durations.get("h", 1)),
                "co2": int(durations.get("co2", 1)),
            },
            "first_actual_sync": bool(data.get("first_actual_sync", False)),
            "saved_at": data.get("saved_at", ""),
        }

        return state

    except Exception as exc:
        print("[WARN] Gagal membaca runtime state: {}".format(exc))
        return None


# ============================================================
# STATE BUILDER
# ============================================================

def build_state(sensor_data, current_status, lamp):
    """
    Membentuk state 11 parameter sesuai training:

    [
        T_in, RH_in, Lux_in, CO2_in,
        T_out, RH_out, Lux_out,
        AC, H, C, L
    ]
    """

    return [
        float(sensor_data["T_in"]),
        float(sensor_data["RH_in"]),
        float(sensor_data["Lux_in"]),
        float(sensor_data["CO2_in"]),
        float(sensor_data["T_out"]),
        float(sensor_data["RH_out"]),
        float(sensor_data["Lux_out"]),
        int(current_status["ac"]),
        int(current_status["h"]),
        int(current_status["co2"]),
        int(lamp),
    ]


def get_status_from_sensor_or_safety(sensor_data, safety):
    """
    Mengambil status aktuator.

    Prioritas:
    1. Jika sensor_reader memberi status aktual dari Influx: AC, H, C, pakai itu.
    2. Kalau tidak ada, pakai status internal safety.current_status.
    """

    fallback = dict(safety.current_status)

    return {
        "ac": int(sensor_data.get("AC", fallback.get("ac", 0))),
        "h": int(sensor_data.get("H", fallback.get("h", 0))),
        "co2": int(sensor_data.get("C", fallback.get("co2", 0))),
    }


# ============================================================
# LOGGING ROW
# ============================================================

def make_log_row(
    timestamp,
    sensor_data,
    lamp,
    prev_status,
    q_values,
    valid_actions,
    selected_action,
    final_action,
    final_status,
    mqtt_status,
    note,
):
    return {
        "timestamp": timestamp,

        "T_in": sensor_data.get("T_in", ""),
        "RH_in": sensor_data.get("RH_in", ""),
        "CO2_in": sensor_data.get("CO2_in", ""),
        "Lux_in": sensor_data.get("Lux_in", ""),

        "T_out": sensor_data.get("T_out", ""),
        "RH_out": sensor_data.get("RH_out", ""),
        "Lux_out": sensor_data.get("Lux_out", ""),

        "lamp": lamp,

        "AC_prev": prev_status.get("ac", ""),
        "H_prev": prev_status.get("h", ""),
        "C_prev": prev_status.get("co2", ""),

        "q_values": format_list(q_values),
        "valid_actions": format_list(valid_actions, ndigits=0),

        "selected_action": selected_action,
        "final_action": final_action,

        "AC_final": final_status.get("ac", ""),
        "H_final": final_status.get("h", final_status.get("humidifier", "")),
        "C_final": final_status.get("co2", ""),

        "mqtt_status": mqtt_status,
        "note": note,
    }


# ============================================================
# INITIAL STATUS
# ============================================================

def load_initial_status():
    """
    Status awal jika runtime state belum ada.

    Catatan:
    - Runtime state lebih diprioritaskan.
    - Kalau logs/dqn_runtime_state.json belum ada, baru pakai INITIAL_ACTION_INDEX.
    """

    initial_action = int(config.INITIAL_ACTION_INDEX)
    return decode_action(initial_action)


def build_safety_controller():
    """
    Membuat SafetyController.

    Prioritas:
    1. Pakai logs/dqn_runtime_state.json jika tersedia.
    2. Jika belum ada, pakai initial status dari config.
    """

    runtime_state = load_runtime_state()

    if runtime_state is not None:
        print("[INFO] Runtime state ditemukan:", RUNTIME_STATE_PATH)
        print("[INFO] Runtime state saved_at:", runtime_state.get("saved_at", ""))

        safety = SafetyController(
            current_status=runtime_state["current_status"],
            durations=runtime_state["durations"],
        )

        safety.first_actual_sync = bool(runtime_state.get("first_actual_sync", False))

        print(
            "[INFO] Runtime status: AC={} H={} CO2={}".format(
                int(safety.current_status.get("ac", 0)),
                int(safety.current_status.get("h", 0)),
                int(safety.current_status.get("co2", 0)),
            )
        )

        print(
            "[INFO] Runtime duration: AC={} H={} CO2={}".format(
                int(safety.durations.get("ac", 1)),
                int(safety.durations.get("h", 1)),
                int(safety.durations.get("co2", 1)),
            )
        )

        return safety

    print("[INFO] Runtime state belum ada, pakai initial status.")

    initial_status = load_initial_status()
    safety = SafetyController(current_status=initial_status)

    return safety


# ============================================================
# TERMINAL DISPLAY
# ============================================================

def print_cycle_report(
    timestamp,
    sensor_data,
    lamp,
    prev_status,
    q_values,
    valid_actions,
    selected_action,
    final_action,
    final_status,
    mqtt_status,
    note,
    raw_state,
    state_norm,
    safety_before,
    safety_after,
):
    selected_action = int(selected_action)
    final_action = int(final_action)

    print("")
    print("=" * 78)
    print("DQN DEPLOYMENT CYCLE")
    print("=" * 78)
    print("Timestamp       : {}".format(timestamp))

    print(
        "Sensor Indoor   : T={:.2f} C | RH={:.2f}% | CO2={:.1f} ppm | Lux={:.1f}".format(
            float(sensor_data["T_in"]),
            float(sensor_data["RH_in"]),
            float(sensor_data["CO2_in"]),
            float(sensor_data["Lux_in"]),
        )
    )

    print(
        "Sensor Outdoor  : T={:.2f} C | RH={:.2f}% | Lux={:.1f}".format(
            float(sensor_data["T_out"]),
            float(sensor_data["RH_out"]),
            float(sensor_data["Lux_out"]),
        )
    )

    print(
        "Status Before   : AC={} | H={} | CO2={} | Lamp={}".format(
            int(prev_status.get("ac", 0)),
            int(prev_status.get("h", 0)),
            int(prev_status.get("co2", 0)),
            int(lamp),
        )
    )

    print("Safety Before   : {}".format(format_safety_debug(safety_before)))

    print("-" * 78)

    print("Q-values        : {}".format(format_q_values(q_values)))
    print("Valid actions   : {}".format(format_valid_actions(valid_actions)))

    print(
        "Selected action : {} -> {}".format(
            selected_action,
            ACTION_TEXT.get(selected_action, "UNKNOWN"),
        )
    )

    print(
        "Selected status : {}".format(
            action_status_text(selected_action)
        )
    )

    print(
        "Final action    : {} -> {}".format(
            final_action,
            ACTION_TEXT.get(final_action, "UNKNOWN"),
        )
    )

    print(
        "Final status    : AC={} | H={} | CO2={}".format(
            int(final_status.get("ac", 0)),
            int(final_status.get("h", final_status.get("humidifier", 0))),
            int(final_status.get("co2", 0)),
        )
    )

    print("Safety After    : {}".format(format_safety_debug(safety_after)))

    print("-" * 78)

    print("MQTT topic      : {}".format(config.MQTT_TOPIC))
    print("MQTT payload    : {}".format({"action": final_action}))
    print("MQTT status     : {}".format(mqtt_status))
    print("Note            : {}".format(note))

    print("-" * 78)

    print("Raw state       : {}".format(
        "[" + ", ".join(["{:.3f}".format(float(x)) for x in raw_state]) + "]"
    ))

    print("Norm state      : {}".format(
        "[" + ", ".join(["{:.3f}".format(float(x)) for x in state_norm]) + "]"
    ))

    print("=" * 78)
    print("")


# ============================================================
# ONE DEPLOY CYCLE
# ============================================================

def run_once(model, sensor_reader, mqtt_client, safety):
    now = datetime.now()
    timestamp = now.isoformat(timespec="seconds")

    # ========================================================
    # 1. Baca sensor terbaru
    # ========================================================
    sensor_data = sensor_reader.read_latest()

    # ========================================================
    # 2. Tentukan status lampu
    # ========================================================
    lamp = get_lamp_status(sensor_data, now=now)

    # ========================================================
    # 3. Ambil status aktual aktuator dari sensor/Influx
    # ========================================================
    actual_status = get_status_from_sensor_or_safety(sensor_data, safety)

    # ========================================================
    # 4. Sinkronkan status aktual ke safety controller
    # ========================================================
    # Penting:
    # - Jangan gunakan safety.current_status = dict(actual_status)
    # - sync_actual_status() akan menangani first sync dan duration counter.
    safety.sync_actual_status(actual_status)

    # Setelah sinkron, pakai status internal safety sebagai state.
    prev_status = dict(safety.current_status)

    # Debug sebelum action dipilih.
    safety_before = safety.debug_status()

    # ========================================================
    # 5. Bentuk state dan normalisasi
    # ========================================================
    raw_state = build_state(sensor_data, prev_status, lamp)
    state_norm = normalize_state(raw_state)

    # ========================================================
    # 6. Inferensi Q-value DQN
    # ========================================================
    q_values = model.predict_q_values(state_norm)

    # ========================================================
    # 7. Safety masking + pemilihan action final
    # ========================================================
    selected_action, final_action, valid_actions = safety.decide_final_action(
        q_values,
        raw_state,
    )

    final_status = decode_action(final_action)

    mqtt_status = "not_published"
    note = "ok"

    # ========================================================
    # 8. Publish action ke MQTT
    # ========================================================
    try:
        # publish_action harus mengirim JSON {"action": final_action}
        mqtt_status = mqtt_client.publish_action(final_action)

        # Counter min ON/OFF hanya di-update jika publish benar-benar sukses.
        if str(mqtt_status) == "published":
            safety.update_after_publish_success(final_action)
        else:
            note = "mqtt_not_confirmed: {}".format(mqtt_status)

    except Exception as exc:
        mqtt_status = "failed"
        note = "mqtt_error: {}".format(exc)

    # Debug setelah publish/update.
    safety_after = safety.debug_status()

    # ========================================================
    # 9. Simpan runtime state
    # ========================================================
    # Ini membuat restart service tidak mengulang duration dari awal.
    save_runtime_state(safety)

    # ========================================================
    # 10. Simpan log CSV
    # ========================================================
    append_log(make_log_row(
        timestamp=timestamp,
        sensor_data=sensor_data,
        lamp=lamp,
        prev_status=prev_status,
        q_values=q_values,
        valid_actions=valid_actions,
        selected_action=selected_action,
        final_action=final_action,
        final_status=final_status,
        mqtt_status=mqtt_status,
        note=note,
    ))

    # ========================================================
    # 11. Print laporan ke terminal/journalctl
    # ========================================================
    print_cycle_report(
        timestamp=timestamp,
        sensor_data=sensor_data,
        lamp=lamp,
        prev_status=prev_status,
        q_values=q_values,
        valid_actions=valid_actions,
        selected_action=selected_action,
        final_action=final_action,
        final_status=final_status,
        mqtt_status=mqtt_status,
        note=note,
        raw_state=raw_state,
        state_norm=state_norm,
        safety_before=safety_before,
        safety_after=safety_after,
    )


# ============================================================
# MAIN
# ============================================================

def main():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--once",
        action="store_true",
        help="Jalankan satu iterasi saja lalu berhenti.",
    )

    parser.add_argument(
        "--max-steps",
        type=int,
        default=None,
        help="Jumlah iterasi maksimum. Default: terus berjalan.",
    )

    parser.add_argument(
        "--interval",
        type=int,
        default=config.CONTROL_INTERVAL_SECONDS,
        help="Interval kontrol dalam detik.",
    )

    args = parser.parse_args()

    if not os.path.exists(config.MODEL_PATH):
        raise FileNotFoundError(
            "Model tidak ditemukan: {}. Letakkan dqn_weights.npz di folder model/.".format(
                config.MODEL_PATH
            )
        )

    print("")
    print("=" * 78)
    print("DQN DEPLOY CONTROLLER START")
    print("=" * 78)
    print("Model path      : {}".format(config.MODEL_PATH))
    print("MQTT topic      : {}".format(config.MQTT_TOPIC))
    print("MQTT format     : {}".format('{"action": final_action}'))
    print("Action range    : 0 sampai 7")
    print("Interval        : {} detik".format(int(args.interval)))
    print("Runtime state   : {}".format(RUNTIME_STATE_PATH))
    print("=" * 78)
    print("")

    print("Memuat model:", config.MODEL_PATH)
    model = DQNModelNPZ(config.MODEL_PATH)

    safety = build_safety_controller()

    sensor_reader = SensorReader()
    mqtt_client = MQTTActionClient()

    step = 0

    try:
        while True:
            try:
                run_once(
                    model=model,
                    sensor_reader=sensor_reader,
                    mqtt_client=mqtt_client,
                    safety=safety,
                )

            except Exception as exc:
                timestamp = datetime.now().isoformat(timespec="seconds")

                print("")
                print("=" * 78)
                print("DQN DEPLOYMENT ERROR")
                print("=" * 78)
                print("Timestamp       : {}".format(timestamp))
                print("Error           : {}".format(exc))
                print("MQTT status     : not_published")
                print("Safety status   : {}".format(format_safety_debug(safety.debug_status())))
                print("=" * 78)
                print("")

                append_log(make_log_row(
                    timestamp=timestamp,
                    sensor_data={},
                    lamp="",
                    prev_status=dict(safety.current_status),
                    q_values=[],
                    valid_actions=[],
                    selected_action="",
                    final_action="",
                    final_status={},
                    mqtt_status="not_published",
                    note="error: {}".format(exc),
                ))

                # Simpan state terakhir meskipun satu cycle error.
                save_runtime_state(safety)

            step += 1

            if args.once:
                break

            if args.max_steps is not None and step >= int(args.max_steps):
                break

            print("Menunggu {} detik ke siklus berikutnya...".format(int(args.interval)))
            time.sleep(int(args.interval))

    finally:
        try:
            save_runtime_state(safety)
        except Exception:
            pass

        try:
            sensor_reader.close()
        except Exception:
            pass

        try:
            mqtt_client.close()
        except Exception:
            pass

        print("")
        print("DQN deploy controller berhenti.")
        print("")


if __name__ == "__main__":
    main()
"""
Normalisasi state deploy.

Urutan state mentah:
[T_in, RH_in, Lux_in, CO2_in, T_out, RH_out, Lux_out, AC, H, C, L]

Harus sama dengan normalisasi saat training.
"""
import numpy as np
import config_deploy as config


def clip01(value):
    return float(np.clip(float(value), 0.0, 1.0))


def minmax(value, min_value, max_value):
    if float(max_value) == float(min_value):
        return 0.0
    return clip01((float(value) - float(min_value)) / (float(max_value) - float(min_value)))


def normalize_state(state):
    T_in, RH_in, Lux_in, CO2_in, T_out, RH_out, Lux_out, ac, h, co2, lamp = state

    normalized = [
        minmax(T_in, *config.NORM["T_in"]),
        minmax(RH_in, *config.NORM["RH_in"]),
        minmax(Lux_in, *config.NORM["Lux_in"]),
        minmax(CO2_in, *config.NORM["CO2_in"]),
        minmax(T_out, *config.NORM["T_out"]),
        minmax(RH_out, *config.NORM["RH_out"]),
        minmax(Lux_out, *config.NORM["Lux_out"]),
        float(ac),
        float(h),
        float(co2),
        float(lamp),
    ]
    return np.asarray(normalized, dtype=np.float32)

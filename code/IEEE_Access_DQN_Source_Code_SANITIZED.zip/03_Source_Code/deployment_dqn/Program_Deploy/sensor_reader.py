"""
sensor_reader.py

Pembaca sensor untuk deployment DQN terbaru.

File ini memakai InfluxEnv agar query InfluxDB sesuai dengan struktur data
Jetson/InfluxDB lama:
- sensor berdasarkan tag topic
- status aktuator dari topic bardi/device_x/power

Output utama read_latest():
{
    "T_in": ...,
    "RH_in": ...,
    "CO2_in": ...,
    "Lux_in": ...,
    "T_out": ...,
    "RH_out": ...,
    "Lux_out": ...,
    "AC": 0/1,
    "H": 0/1,
    "C": 0/1,
    "L": 0/1
}
"""

from datetime import datetime

import config_deploy as config
from influx_env import InfluxEnv


class SensorReader(object):
    def __init__(self):
        self.env = InfluxEnv()

    def close(self):
        try:
            self.env.close()
        except Exception:
            pass

    def read_latest(self):
        """
        Membaca data sensor terbaru dan status aktuator.

        Return sudah cocok untuk state DQN terbaru:
        [T_in, RH_in, Lux_in, CO2_in, T_out, RH_out, Lux_out, AC, H, C, L]
        """

        data = self.env.read_state_data()
        self.validate_sensor_data(data)
        return data

    def validate_sensor_data(self, data):
        """
        Validasi agar program tidak publish action jika data sensor tidak masuk akal.
        """
        for key, value in data.items():
            if key not in config.SENSOR_VALID_RANGE:
                continue

            low, high = config.SENSOR_VALID_RANGE[key]

            try:
                numeric_value = float(value)
            except Exception:
                raise RuntimeError(
                    "Nilai sensor/status {} tidak numerik: {}".format(key, value)
                )

            if numeric_value < low or numeric_value > high:
                raise RuntimeError(
                    "Nilai sensor/status {} tidak valid: {} di luar {}-{}".format(
                        key,
                        numeric_value,
                        low,
                        high,
                    )
                )


def get_lamp_status(sensor_data, now=None):
    """
    Menentukan status lampu L: 0/1.

    Prioritas:
    1. Jika sensor_data sudah punya "L", pakai itu.
    2. Jika config LAMP_STATUS_SOURCE = "lux", pakai Lux_in.
    3. Default pakai jadwal 06.00-22.00.
    """

    if "L" in sensor_data:
        return int(sensor_data["L"])

    if now is None:
        now = datetime.now()

    if str(config.LAMP_STATUS_SOURCE).lower() == "lux":
        return 1 if float(sensor_data.get("Lux_in", 0.0)) >= float(config.LAMP_LUX_THRESHOLD) else 0

    hour = now.hour + now.minute / 60.0 + now.second / 3600.0

    if config.LAMP_ON_HOUR <= hour < config.LAMP_OFF_HOUR:
        return 1

    return 0
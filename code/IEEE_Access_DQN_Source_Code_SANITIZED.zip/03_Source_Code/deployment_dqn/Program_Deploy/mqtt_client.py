"""
mqtt_client.py

Client MQTT untuk mengirim action DQN ke receiver aktuator.

Catatan:
- Model DQN menghasilkan action index 0-7.
- Receiver aktuator kamu membaca format JSON: {"action": 1}
- Jadi MQTT tidak mengirim angka polos "1", tetapi JSON berisi action.
"""

import json
import paho.mqtt.client as mqtt

import config_deploy as config


class MQTTActionClient(object):
    def __init__(self):
        self.client = mqtt.Client(client_id=config.MQTT_CLIENT_ID)
        self.connected = False

    def connect(self):
        host = getattr(config, "MQTT_HOST", None)

        if host is None:
            host = getattr(config, "MQTT_BROKER", "localhost")

        port = int(getattr(config, "MQTT_PORT", 1883))

        print("[MQTT] Connecting to {}:{} ...".format(host, port))

        self.client.connect(host, port, keepalive=60)
        self.client.loop_start()

        self.connected = True

        print("[MQTT] Connected")

    def close(self):
        try:
            self.client.loop_stop()
            self.client.disconnect()
        except Exception:
            pass

        self.connected = False

    def publish_action(self, action_index):
        """
        Publish action ke MQTT.

        Format payload:
            {"action": 1}

        Bukan:
            1

        Karena receiver aktuator membaca:
            data = json.loads(payload)
            action = data.get("action")
        """

        if not self.connected:
            self.connect()

        action_index = int(action_index)

        if action_index < 0 or action_index > 7:
            raise ValueError("Action index tidak valid: {}".format(action_index))

        payload = json.dumps({
            "action": action_index
        })

        result = self.client.publish(
            config.MQTT_TOPIC,
            payload=payload,
            qos=int(getattr(config, "MQTT_QOS", 1)),
            retain=False,
        )

        try:
            result.wait_for_publish(timeout=5)
        except TypeError:
            result.wait_for_publish()

        if result.rc == mqtt.MQTT_ERR_SUCCESS:
            return "published"

        return "publish_failed_rc_{}".format(result.rc)


# Alias tambahan agar tetap aman kalau ada file lain
# yang memanggil nama class versi sebelumnya.
MqttActuatorClient = MQTTActionClient
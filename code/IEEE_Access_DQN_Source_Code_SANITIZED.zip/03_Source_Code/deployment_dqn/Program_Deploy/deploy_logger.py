"""
Logger CSV untuk deployment DQN.
"""
import csv
import os

import config_deploy as config


FIELDNAMES = [
    "timestamp",
    "T_in", "RH_in", "CO2_in", "Lux_in",
    "T_out", "RH_out", "Lux_out",
    "lamp",
    "AC_prev", "H_prev", "C_prev",
    "q_values",
    "valid_actions",
    "selected_action",
    "final_action",
    "AC_final", "H_final", "C_final",
    "mqtt_status",
    "note",
]


def ensure_log_dir():
    folder = os.path.dirname(config.LOG_PATH)
    if folder and not os.path.exists(folder):
        os.makedirs(folder)


def append_log(row):
    ensure_log_dir()
    file_exists = os.path.exists(config.LOG_PATH)
    with open(config.LOG_PATH, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        if not file_exists:
            writer.writeheader()
        writer.writerow(row)


def format_list(values, ndigits=4):
    if values is None:
        return ""
    out = []
    for value in values:
        try:
            out.append(str(round(float(value), ndigits)))
        except Exception:
            out.append(str(value))
    return ";".join(out)


def read_last_final_action():
    if not os.path.exists(config.LOG_PATH):
        return None
    try:
        with open(config.LOG_PATH, "r", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        for row in reversed(rows):
            value = row.get("final_action")
            if value is not None and str(value).strip() != "":
                return int(float(value))
    except Exception:
        return None
    return None

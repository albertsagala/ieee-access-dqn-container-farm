#!/usr/bin/env python3

"""
rule_based_controller.py

Rule-based controller dengan hysteresis untuk kontrol iklim indoor farming.
Menggantikan main_deploy.py (DQN).

Setpoint & Hysteresis:
  Suhu  : ON  jika > 24°C  (AC ON)  | OFF jika < 22°C  (AC OFF)
  RH    : ON  jika < 50%   (Hum ON) | OFF jika > 65%   (Hum OFF)
  CO2   : ON  jika < 800ppm (CO2 ON) | OFF jika > 950ppm (CO2 OFF)

Safety:
  - CO2 tidak boleh ON saat lampu mati
  - State tracking: tidak kirim MQTT jika aktuator sudah dalam kondisi yang benar
"""

import time
import json
import logging
import sys
from datetime import datetime
from typing import Optional

import paho.mqtt.client as mqtt
from influx_env import InfluxEnv

# ==================== KONFIGURASI ====================
INFLUX_URL    = "http://INFLUXDB_HOST:8086"
INFLUX_TOKEN  = "REPLACE_WITH_YOUR_INFLUX_TOKEN"
INFLUX_ORG    = "IT Del"
INFLUX_BUCKET = "Monitoring"
MEASUREMENT_STATE = "mqtt_consumer"

MQTT_BROKER    = "MQTT_BROKER_HOST"
MQTT_PORT      = 1883
MQTT_TOPIC     = "actuator/command"
MQTT_CLIENT_ID = "rule_based_controller"

INTERVAL = 300  # detik antar siklus kontrol

# ==================== SETPOINT & HYSTERESIS ====================
# Suhu (AC)
TEMP_ON_THRESHOLD  = 24.0   # AC ON  jika suhu > nilai ini
TEMP_OFF_THRESHOLD = 20.0   # AC OFF jika suhu < nilai ini

# Kelembaban (Humidifier)
RH_ON_THRESHOLD  = 60.0     # Hum ON  jika RH < nilai ini
RH_OFF_THRESHOLD = 70.0     # Hum OFF jika RH > nilai ini

# CO2
CO2_ON_THRESHOLD  = 800.0   # CO2 ON  jika CO2 < nilai ini
CO2_OFF_THRESHOLD = 950.0   # CO2 OFF jika CO2 > nilai ini

# ==================== ACTION CODES ====================
ACTION_AC_OFF  = 0
ACTION_AC_ON   = 1
ACTION_HUM_OFF = 2
ACTION_HUM_ON  = 3
ACTION_CO2_OFF = 4
ACTION_CO2_ON  = 5
ACTION_NOOP    = 6

# ==================== LOGGING ====================
# stdout → ditangkap journalctl saat dijalankan via systemd
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[logging.StreamHandler(sys.stdout)]
)
log = logging.getLogger(__name__)

# ==================== MQTT ACTUATOR ====================
class MQTTActuator:
    def __init__(self, broker, port, topic, client_id=""):
        self.broker = broker
        self.port   = port
        self.topic  = topic
        self.client = mqtt.Client(client_id=client_id, clean_session=True)
        self.client.on_connect    = self._on_connect
        self.client.on_disconnect = self._on_disconnect
        self.connected = False
        try:
            self.client.connect(self.broker, self.port, keepalive=60)
            self.client.loop_start()
        except Exception as e:
            log.error(f"Gagal koneksi MQTT awal: {e}")

    def _on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            self.connected = True
            log.info(f"Terhubung ke MQTT broker {self.broker}:{self.port}")
        else:
            log.error(f"Gagal konek MQTT, kode {rc}")

    def _on_disconnect(self, client, userdata, rc):
        self.connected = False
        log.warning("Terputus dari MQTT broker")

    def send_action(self, action: int, label: str = ""):
        payload = json.dumps({"action": action})
        try:
            info = self.client.publish(self.topic, payload, qos=1)
            info.wait_for_publish(timeout=2)
            if info.rc == mqtt.MQTT_ERR_SUCCESS:
                log.info(f"MQTT publish → action={action} ({label})")
            else:
                log.warning(f"Gagal publish action={action}, kode {info.rc}")
        except Exception as e:
            log.error(f"Exception saat publish MQTT: {e}")

    def cleanup(self):
        self.client.loop_stop()
        self.client.disconnect()
        log.info("Koneksi MQTT ditutup")


# ==================== RULE-BASED CONTROLLER ====================
class RuleBasedController:
    def __init__(self, actuator: MQTTActuator):
        self.actuator = actuator

        # State tracking aktuator terakhir yang diketahui
        # None = belum diketahui, akan dikirim perintah pada siklus pertama
        self.ac_on  : Optional[bool] = None
        self.hum_on : Optional[bool] = None
        self.co2_on : Optional[bool] = None

    def _send_if_changed(self, current: Optional[bool], target: bool,
                          action_on: int, action_off: int,
                          label: str) -> bool:
        """
        Kirim perintah MQTT hanya jika state berubah.
        Return state terbaru.
        """
        if current == target:
            return current  # tidak ada perubahan, skip
        action = action_on if target else action_off
        self.actuator.send_action(action, label)
        return target

    def evaluate(self, temp: float, rh: float, co2: float, lamp_on: bool):
        """
        Evaluasi semua sensor dan kirim aksi yang diperlukan.
        Dipanggil setiap siklus kontrol.
        """
        log.info(
            f"Sensor → Suhu={temp:.1f}°C | RH={rh:.1f}% | "
            f"CO2={co2:.0f}ppm | Lampu={'ON' if lamp_on else 'OFF'}"
        )

        # ---------- SUHU → AC ----------
        if temp > TEMP_ON_THRESHOLD:
            target_ac = True
        elif temp < TEMP_OFF_THRESHOLD:
            target_ac = False
        else:
            # Di zona hysteresis (22–24°C), pertahankan state sebelumnya
            target_ac = self.ac_on if self.ac_on is not None else False

        self.ac_on = self._send_if_changed(
            self.ac_on, target_ac,
            ACTION_AC_ON, ACTION_AC_OFF,
            "AC ON" if target_ac else "AC OFF"
        )

        # ---------- KELEMBABAN → HUMIDIFIER ----------
        if rh < RH_ON_THRESHOLD:
            target_hum = True
        elif rh > RH_OFF_THRESHOLD:
            target_hum = False
        else:
            # Di zona hysteresis (50–65%), pertahankan state sebelumnya
            target_hum = self.hum_on if self.hum_on is not None else False

        self.hum_on = self._send_if_changed(
            self.hum_on, target_hum,
            ACTION_HUM_ON, ACTION_HUM_OFF,
            "Humidifier ON" if target_hum else "Humidifier OFF"
        )

        # ---------- CO2 ----------
        if co2 < CO2_ON_THRESHOLD:
            target_co2 = True
        elif co2 > CO2_OFF_THRESHOLD:
            target_co2 = False
        else:
            # Di zona hysteresis (800–950ppm), pertahankan state sebelumnya
            target_co2 = self.co2_on if self.co2_on is not None else False

        # Safety: CO2 tidak boleh ON saat lampu mati
        if target_co2 and not lamp_on:
            log.warning("Safety override: CO2 ON diblokir karena lampu mati")
            target_co2 = False

        self.co2_on = self._send_if_changed(
            self.co2_on, target_co2,
            ACTION_CO2_ON, ACTION_CO2_OFF,
            "CO2 ON" if target_co2 else "CO2 OFF"
        )

        # ---------- LOG RINGKASAN ----------
        log.info(
            f"Status aktuator → AC={'ON' if self.ac_on else 'OFF'} | "
            f"Hum={'ON' if self.hum_on else 'OFF'} | "
            f"CO2={'ON' if self.co2_on else 'OFF'}"
        )


# ==================== MAIN LOOP ====================
def main():
    log.info("=" * 55)
    log.info("Rule-Based Controller - Kontrol Iklim Indoor Farming")
    log.info("=" * 55)
    log.info(f"Setpoint  → Suhu: {TEMP_OFF_THRESHOLD}–{TEMP_ON_THRESHOLD}°C | "
             f"RH: {RH_ON_THRESHOLD}–{RH_OFF_THRESHOLD}% | "
             f"CO2: {CO2_ON_THRESHOLD}–{CO2_OFF_THRESHOLD}ppm")
    log.info(f"Interval  → {INTERVAL} detik")

    env      = InfluxEnv(INFLUX_URL, INFLUX_TOKEN, INFLUX_ORG,
                         INFLUX_BUCKET, MEASUREMENT_STATE)
    actuator = MQTTActuator(MQTT_BROKER, MQTT_PORT, MQTT_TOPIC, MQTT_CLIENT_ID)
    ctrl     = RuleBasedController(actuator)

    env.reset()
    step = 0

    log.info("Loop kontrol dimulai... (Ctrl+C untuk berhenti)")

    try:
        while True:
            step += 1
            try:
                raw      = env._get_raw_state()
                temp     = raw["T_in"]
                rh       = raw["RH_in"]
                co2      = raw["CO2_in"]
                lamp_on  = env.lamp_on

                log.info(f"--- Siklus #{step} ---")
                ctrl.evaluate(temp, rh, co2, lamp_on)

            except Exception as e:
                log.error(f"Error pada siklus #{step}: {e}")

            time.sleep(INTERVAL)

    except KeyboardInterrupt:
        log.info("Interupsi keyboard, menghentikan program...")
    finally:
        actuator.cleanup()
        log.info("Program dihentikan bersih.")


if __name__ == "__main__":
    main()

# Public release note

This source-code snapshot corresponds to the implementation described in the IEEE Access manuscript.

For public release, private deployment credentials and local-network addresses have been removed or replaced with environment-variable placeholders. No functional control logic, DQN architecture, reward formulation, or analysis logic was changed by this sanitization.

Configure deployment-specific values using environment variables or local configuration files that are not committed to version control.

# Preprocessing Notes

Langkah preprocessing yang perlu dijelaskan di naskah:
1. Data diekspor dari dashboard/InfluxDB dan log deployment DQN.
2. Data DQN dipotong menjadi periode 24 jam.
3. Timestamp diseragamkan.
4. Kolom sensor, status aktuator, daya, energi, dan action dipilih.
5. Data rule-based dan DQN dibandingkan pada durasi 24 jam, tetapi hari uji dan interval kontrol berbeda.
6. Waktu ideal dihitung berdasarkan rentang ideal: suhu 20-24 C, RH 60-70%, CO2 800-1000 ppm.
7. Energi dihitung dari daya aktuator terhadap waktu.
8. Summary reward sensitivity dan multiseed berasal dari eksperimen simulasi ulang.

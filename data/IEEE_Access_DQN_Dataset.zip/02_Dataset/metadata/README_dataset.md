# Dataset Raj Damanik - DQN Indoor Farming

Folder ini berisi data yang sudah tersedia dari percakapan/proses revisi.

Catatan penting:
- Nama file di folder ini sudah dirapikan agar mudah dikumpulkan ke dosen.
- Data DQN deployment 24 jam ada di `raw/dqn_deployment/dqn_deploy_log_24jam.csv`.
- Log DQN yang dilengkapi raw/final action ada di `raw/dqn_deployment/dqn_deploy_log_24jam_enriched_raw_action.csv`.
- Data sensor DQN dari dashboard/InfluxDB berada di `raw/dqn_sensor_exports/`.
- Data sensor rule-based berada di `raw/rule_based_sensor_exports/`.
- Summary training ulang reward sensitivity dan multiseed berada di `processed/`.

File yang belum tersedia sebagai satu CSV gabungan dan perlu dibuat jika diminta dosen:
- `dqn_24jam_processed.csv`
- `rule_based_24jam_processed.csv`
- `processed_24jam_comparison.csv`
- `ideal_time_summary.csv`
- `energy_summary_24jam.csv`
- `actuator_on_switching_summary.csv`
- `overshoot_response_settling_summary.csv`

Nilai-nilai file summary tersebut sudah dipakai di Bab IV, tetapi CSV gabungannya perlu dibuat dari data raw atau diekspor dari script analisis.
